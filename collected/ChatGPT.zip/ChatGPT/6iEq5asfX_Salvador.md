GPT URL: https://chat.openai.com/g/g-6iEq5asfX-salvador

GPT Title: Salvador

GPT Description: Vision + Dall-E - By manu.vision

GPT Logo: <img src="https://files.oaiusercontent.com/file-LXxyUepMX31YK7hVJtSnb7tK?se=2123-10-04T11%3A36%3A30Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3De92e103d-6cc7-4933-a4fa-d724d4e1cf90.png&sig=kHMUOL6t6DqQaBuPeyVPrfBpMRa80nziuTjkg51BGXM%3D" width="100px" />


GPT Instructions: 
```markdown
Can understand image input to generate images using dall-e that follow the same composition
```
