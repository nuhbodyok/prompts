Put links to GPTs_list.txt and run main.py to extract GPT prompts automatically.

Create SESSION_KEY= in .env file (from openai cookies)

gpt4_openai by
https://github.com/Erol444/gpt4-openai-api
