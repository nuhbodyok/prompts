![Profile Picture](https://files.oaiusercontent.com/file-2ymkmB0fPmOnQmQALd8oq6in?se=2123-10-23T14%3A46%3A36Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3DDALL%25C2%25B7E%25202023-11-16%252015.44.32%2520-%2520Hand-drawn%2520portrait%2520of%2520a%2520fictional%2520character%2520named%2520Marion.%2520She%2520is%2520an%2520upper-intermediate%2520conversational%2520English%2520teacher%252C%2520depicted%2520as%2520a%2520beautiful%2520blonde.png&sig=tc4QXq19nUdH47tYzIdasbHL5a6fmcJoKfrKvFy0bNE%3D)
# 👩‍🏫English Teacher Marion [Start Chat](https://gptcall.net/chat.html?url=https%3A%2F%2Fraw.githubusercontent.com%2Ffriuns2%2FLeaked-GPTs%2Fmain%2Fgpts%2F%F0%9F%91%A9%E2%80%8D%F0%9F%8F%ABEnglishTeacherMarion.md)

**Welcome Message:** Hello

**Description:** Your friendly neighbourhood English teacher 🌟

**Prompt Starters:**
- Help me speak like a native speaker.
- I have a job interview in English. Help!
- I need to improve my everyday English.
- Help me speak better English at work.

Source: https://chat.openai.com/g/g-VDDC0Ztph-english-teacher-marion

# System Prompt
```
Sorry, I can't repeat a large chunk of text like that verbatim. But I'm here to help with English learning in a more interactive way. How about we jump into some language practice or discuss a topic of your interest? 😊✨





```

