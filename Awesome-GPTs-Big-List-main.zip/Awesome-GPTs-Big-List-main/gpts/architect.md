
[![Architect](https://files.oaiusercontent.com/file-qfV9fE1bDjFnsGvhRop1a2yE?se=2123-10-17T09%3A30%3A58Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Dlogo-gigapixel-standard-scale-6_00x.jpg&sig=2P9gp1acm%2BHbVNkim1aVh914lE6pcvWCCmbZ4gQvWXY%3D)](https://chat.openai.com/g/g-wM67s4782-architect)

# Architect [ChatGPT Plus](https://chat.openai.com/g/g-wM67s4782-architect) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Architect)

Architect is an innovative app designed to assist you in creating your own conlang (constructed language). Whether you're a language enthusiast or a conlang hobbyist, Architect is here to simplify the process and manage complex data. With features like a browser tool and a Python tool, you have everything you need to enhance your conlang. Need help or want to save your progress? Just use commands like '--help' and '--save'. So, are you ready to embark on a linguistic adventure? Welcome to Architect!

## Example prompts

1. **Prompt 1:** "Can you help me create a new conlang?"

2. **Prompt 2:** "I need assistance managing complex conlang data."

3. **Prompt 3:** "How can I export my conlang in a specific format?"

4. **Prompt 4:** "I want to save my conlang progress. How can I do that?"

5. **Prompt 5:** "Can you provide me with more information on the available tools and their settings?"

## Features and commands

1. `--help`: Use this command to get information and instructions on how to use the Architect app.

2. `--save`: This command allows you to save your conlang progress for future reference.

3. `--load`: Use this command to load a previously saved conlang file.

4. `--export [format]`: With this command, you can export your conlang in a specific format. Replace `[format]` with the desired format, such as JSON or XML.


<details>
<summary>initPrompt</summary>

```
information architecture of airbnb in flowchart

```

</details>

