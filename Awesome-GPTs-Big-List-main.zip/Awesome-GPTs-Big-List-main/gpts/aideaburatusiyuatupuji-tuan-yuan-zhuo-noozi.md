
[![アイデアブラッシュアップ集団「円卓のおじ」](https://files.oaiusercontent.com/file-MM0LUABUvL6eX9xeYjspPc0k?se=2123-10-19T16%3A56%3A05Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Dtfs137_Knights_of_the_Round_Table_composed_of_old_men_04606f59-ce5c-4184-83f3-68488fb74f4c.png&sig=jrhrIosusVPtLlVCVjPSmBF52OhI0AJ9lmQalr7KBdk%3D)](https://chat.openai.com/g/g-rMZVm3oXO-aideaburatusiyuatupuji-tuan-yuan-zhuo-noozi)

# アイデアブラッシュアップ集団「円卓のおじ」 [ChatGPT Plus](https://chat.openai.com/g/g-rMZVm3oXO-aideaburatusiyuatupuji-tuan-yuan-zhuo-noozi) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=%E3%82%A2%E3%82%A4%E3%83%87%E3%82%A2%E3%83%96%E3%83%A9%E3%83%83%E3%82%B7%E3%83%A5%E3%82%A2%E3%83%83%E3%83%97%E9%9B%86%E5%9B%A3%E3%80%8C%E5%86%86%E5%8D%93%E3%81%AE%E3%81%8A%E3%81%98%E3%80%8D)

This App, called 'アイデアブラッシュアップ集団「円卓のおじ」' (Idea Brush-up Group: Round Table Uncle), is here to help you refine your ideas. Whether it's a business concept, a creative project, or anything else, this App will thoroughly analyze and critique your ideas to help you improve them. With the ability to input your ideas and receive constructive feedback, you can make sure your ideas are polished and ready to go. So, why not gather around the virtual Round Table Uncle and let him give your ideas a good brush-up!

## Example prompts

1. **Prompt 1:** "開始して下さい。"

## Features and commands

1. `開始して下さい。` - This command starts the interaction with the アイデアブラッシュアップ集団「円卓のおじ」(Idea Brainstorming Group "Uncle at the Round Table") app.

Please note that without access to knowledge, the アイデアブラッシュアップ集団「円卓のおじ」app may have limited functionality.


