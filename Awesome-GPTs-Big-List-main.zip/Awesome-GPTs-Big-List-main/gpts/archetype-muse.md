
[![Archetype Muse](https://files.oaiusercontent.com/file-1D9Rq5qnvFklPotWttVUifD1?se=2123-10-18T14%3A43%3A25Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Dee08065e-b795-4236-a7ff-446342a56476.png&sig=YWatQLoux3q8y8qqZtUPzviF1JRNybtO9oZmC7ZTJ2I%3D)](https://chat.openai.com/g/g-R2XpsARWL-archetype-muse)

# Archetype Muse [ChatGPT Plus](https://chat.openai.com/g/g-R2XpsARWL-archetype-muse) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Archetype%20Muse)

Archetype Muse is a poll-based content creator app developed by Tabby Digital. It helps you choose your brand's archetype through fun and interactive polls. Whether you want to create content for an adventurer brand, design humorous ad campaigns for a Jester brand, or establish an empathetic social media presence for a Caregiver brand, this app has got you covered. Start by taking a poll to select your brand's archetype, and then use the provided tools to bring your ideas to life. With Archetype Muse, you can unleash your creativity and build a strong brand identity.

## Example prompts

1. **Prompt 1:** "Take a poll to select my brand's archetype."

2. **Prompt 2:** "Compose content for an Explorer brand's adventure blog."

3. **Prompt 3:** "Create a Jester brand's humorous ad campaign."

4. **Prompt 4:** "Design a Caregiver brand's empathetic social media presence."

## Features and commands

1. Archetype Selection: You can start by taking a poll to select your brand's archetype. This will help determine the tone and style of your content.

2. Blog Content Generation: Use the app to compose engaging content for an Explorer brand's adventure blog. It can assist you in generating creative and captivating blog posts.

3. Ad Campaign Creation: For a Jester brand, the app can help you design a humorous ad campaign. It can provide ideas and concepts for catchy advertisements.

4. Social Media Presence Design: If you have a Caregiver brand, the app can assist you in designing an empathetic social media presence. It can help you create content that resonates with your audience and showcases your brand's caring nature.


