
[![Airwise](https://files.oaiusercontent.com/file-74Wqsq0F2HGfrQLZMAAshoEg?se=2123-10-19T09%3A56%3A05Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D3dace1c4-c667-4a18-9e74-9e892a368e21.png&sig=suQM2D1bewTvwN%2B4kNfjtzAm3HrXpSJDaFcp3OE8RIU%3D)](https://chat.openai.com/g/g-YxfbZUa7H-airwise)

# Airwise [ChatGPT Plus](https://chat.openai.com/g/g-YxfbZUa7H-airwise) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Airwise)

Airwise is a handy AI tool designed for travelers. With Airwise, you can quickly clarify airport regulations on carry-on and checked items, ensuring that you stay aligned with current global policies. Simply upload images of the items you're unsure about, and Airwise will let you know if they are permitted at Indian airports. Have a question about carrying perfume in your luggage or bringing a cricket kit through airport security? Airwise has got you covered! It's like having a knowledgeable airport guide in your pocket. Oh, and by the way, it can even help you find out if lighters are allowed on flights. Bon voyage!

## Example prompts

1. **Prompt 1:** "Are the items shown in these uploaded images permitted at Indian airports?"

2. **Prompt 2:** "Is perfume permitted to be carried in luggage at airports?"

3. **Prompt 3:** "How can I carry a cricket kit through airport security?"

4. **Prompt 4:** "Are lighters allowed on flights at airports?"

## Command names and descriptions

1. `checkRegulations`: Checks the airport regulations on carry-on and checked items.

2. `readFAQs`: Reads frequently asked questions about airport regulations.

3. `viewDocuments`: Displays relevant documents and policies related to airport regulations.

4. `searchRegulations`: Searches for specific information regarding airport regulations.

5. `askQuestion`: Asks a question about airport regulations.

Note: The above commands are hypothetical and may not correspond exactly to the features and commands of the Airwise App. Please refer to the App documentation for accurate information.


