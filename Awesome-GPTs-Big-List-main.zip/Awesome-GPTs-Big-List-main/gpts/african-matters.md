
[![African matters](https://files.oaiusercontent.com/file-i5bagrUadAX62MYqCLgGkXuO?se=2123-10-18T10%3A12%3A42Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D940decb5-53ab-4f02-bc41-0491deb422e6.png&sig=LZTbemOvm5JF9cE3dyznewQy7rf593MQ9bo5rh%2Bebjk%3D)](https://chat.openai.com/g/g-ktLz9DMAT-african-matters)

# African matters [ChatGPT Plus](https://chat.openai.com/g/g-ktLz9DMAT-african-matters) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=African%20matters)

African matters is an App that provides knowledge and information on African people and various matters related to the continent. Whether you're interested in learning about African history, culture, art, or current affairs, this App has got you covered. Say 'I'm interested in learning' to get started and explore a wide range of topics. With African matters, you can broaden your understanding of Africa and its rich heritage. Welcome to a world of African knowledge!

## Example prompts

1. **Prompt 1:** "I'm interested in learning about African history and culture."

2. **Prompt 2:** "Can you provide information on current events in Africa?"

3. **Prompt 3:** "I want to explore traditional African music and dance."

4. **Prompt 4:** "Can you recommend books or documentaries about African wildlife?"

5. **Prompt 5:** "I would like to learn about influential African leaders throughout history."

## Features and commands

1. `search <keyword>` - Allows you to search for information on a specific topic related to Africa. Example: "Search Nelson Mandela".

2. `explore <category>` - Provides a curated list of categories for you to explore various aspects of African knowledge. Example: "Explore African art".

3. `recommend <type>` - Offers recommendations based on the specified type, such as books, movies, or music, related to Africa. Example: "Recommend African literature".

4. `translate <text>` - Translates the specified text into a selected African language. Example: "Translate hello into Swahili".

5. `ask <question>` - Allows you to ask a specific question about African matters. Example: "Ask about traditional African clothing".

Remember to start your conversation with the app by greeting it with a simple "Hello"!


