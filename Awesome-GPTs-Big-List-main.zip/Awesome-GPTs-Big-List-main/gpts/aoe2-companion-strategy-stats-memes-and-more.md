
[![AOE2 Companion: Strategy, stats, memes and more](https://files.oaiusercontent.com/file-2MymuLJU7WeW5EdVQUk4qQFV?se=2123-10-18T20%3A25%3A13Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D115a055f-712d-4021-8895-020eb60525f3.png&sig=iKY82Timh/Iw9LzgMRQluhcRJ5ortEU%2B1sQ87LHLF7I%3D)](https://chat.openai.com/g/g-a4eC8PB0g-aoe2-companion-strategy-stats-memes-and-more)

# AOE2 Companion: Strategy, stats, memes and more [ChatGPT Plus](https://chat.openai.com/g/g-a4eC8PB0g-aoe2-companion-strategy-stats-memes-and-more) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AOE2%20Companion%3A%20Strategy%2C%20stats%2C%20memes%20and%20more)

AOE2 Companion is your witty guide to mastering Age of Empires 2. Whether you're a beginner or a seasoned strategist, this app has got you covered with strategies, stats, memes, and more! Explore different ways to build the perfect castle and learn how to win using only villagers. You can even dive into the AOE2 economy using clever food puns. Not only that, but the app also sparks your imagination with a crossover between AOE2 and a sci-fi game. Get ready to conquer today with AOE2 Companion!

## Example prompts

1. **Prompt 1:** "What's Daut's secret to building the perfect castle?"

2. **Prompt 2:** "How do you win with only villagers in AOE2?"

3. **Prompt 3:** "Can you explain the AOE2 economy using only food puns?"

4. **Prompt 4:** "What would a crossover between AOE2 and a sci-fi game look like?"

## Features and commands

| Feature/Command | Description |
| --- | --- |
| No specific commands available for the AOE2 Companion app. The app provides a witty guide to mastering Age of Empires 2, including strategies, stats, memes, and more. It does not have access to external knowledge or specific tools. |



