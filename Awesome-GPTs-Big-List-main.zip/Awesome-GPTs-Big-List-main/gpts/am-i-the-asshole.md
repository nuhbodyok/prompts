
[![Am I the Asshole](https://files.oaiusercontent.com/file-D8M0DO5iM08CWO0yC8t00E4Z?se=2123-10-18T00%3A02%3A39Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D1f2049f0-00b0-4c7e-97b5-a3abf855a871.png&sig=2EDtsrMNWqvxDotlzI3uQTQgIOCR8zUEE6x5swNcTeA%3D)](https://chat.openai.com/g/g-41IVSqXcI-am-i-the-asshole)

# Am I the Asshole [ChatGPT Plus](https://chat.openai.com/g/g-41IVSqXcI-am-i-the-asshole) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Am%20I%20the%20Asshole)

Discover if you were in the wrong during a heated argument with the Am I the Asshole app. Share your conflict and let the app determine if you made the right choice. Whether it's refusing to lend money, missing a family event, addressing a coworker's outfit, or canceling plans, this app will provide unbiased feedback. With prompt starters to kick off your story, you'll get guidance and clarity. Am I the Asshole is your go-to companion when you need to settle an ongoing disagreement.

## Example prompts

1. **Prompt 1:** "Am I wrong for refusing to lend money to my friend?"

2. **Prompt 2:** "Is it bad that I didn't attend my brother's wedding?"

3. **Prompt 3:** "Was I right to confront my coworker about their slutty outfit?"

4. **Prompt 4:** "Should I apologize for canceling plans last minute?"

## Features and commands

1. **Welcome message**: The ChatGPT App will greet you with a message: "Hi! Tell me your conflict, and I'll help you figure out if you're in the right or not."

2. **Browser tool**: The App has access to a browser tool. You can use it to retrieve information or search for relevant content related to your conflict.

3. **DALL·E tool**: The App also has access to a DALL·E tool, which can assist in generating visual representations or providing creative input for your conflict.

Note: The documentation does not provide specific information about additional commands or parameters for the App.


