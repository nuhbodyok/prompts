
[![AI Juan Ignacio Segura](https://files.oaiusercontent.com/file-vStv9Grjn2gYx2RrMob0Lq14?se=2123-10-17T00%3A58%3A29Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D1516319414425.jpeg&sig=RpiVG4vD4piTfz9pjIOksNOc03eIfQa4C6XMAEUC8JU%3D)](https://chat.openai.com/g/g-RDlBJyCDg-ai-juan-ignacio-segura)

# AI Juan Ignacio Segura [ChatGPT Plus](https://chat.openai.com/g/g-RDlBJyCDg-ai-juan-ignacio-segura) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AI%20Juan%20Ignacio%20Segura)

AI Juan Ignacio Segura is a Product Vision and Strategy Advisor. Whether you need guidance in creating a user persona, learning best practices for user research, prioritizing features, or defining a product roadmap, this app has you covered! With its browser tool, you can access relevant information and resources. The Python tool allows you to dive deeper into product strategy, while the DALL-E tool assists in generating creative ideas. Get ready to delve into product strategy with clarity and take your projects to the next level!

## Example prompts

1. **Prompt 1:** "Guide me through creating a user persona."

2. **Prompt 2:** "What are the best practices for user research?"

3. **Prompt 3:** "How do I prioritize features?"

4. **Prompt 4:** "Define a product roadmap."

## Features and commands

1. **Create User Persona**: This command guides you through the process of creating a user persona for your product. User personas help you understand your target audience and tailor your product to their needs and preferences.

2. **Best Practices for User Research**: This command provides you with a list of best practices for conducting user research. User research is crucial for understanding your users, their goals, and their pain points, and it helps shape your product strategy.

3. **Prioritize Features**: This command provides guidance on how to prioritize features for your product. Prioritizing features involves assessing their impact, feasibility, and alignment with your overall product strategy.

4. **Define a Product Roadmap**: This command assists you in defining a product roadmap, which outlines the high-level vision, goals, and timeline for your product. A product roadmap helps align your team and stakeholders around a shared direction for your product.

Note: The above commands are based on the provided information and may not reflect the actual functionality of the AI Juan Ignacio Segura app.


