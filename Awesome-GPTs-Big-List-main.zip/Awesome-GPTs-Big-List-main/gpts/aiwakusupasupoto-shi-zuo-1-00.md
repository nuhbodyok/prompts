
[![アイワークス・パスポート（試作1.00）](https://files.oaiusercontent.com/file-aNQcHsgae8HLFxjapEGDknmB?se=2123-10-17T04%3A53%3A36Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D%25E3%2582%25A2%25E3%2582%25A4%25E3%2583%25BB%25E3%2583%25AF%25E3%2583%25BC%25E3%2582%25AF%25E3%2582%25B9.png&sig=/a8TyaIgRIDVA992wLrOy7P/6mZ3zWi0VMY876Eph/M%3D)](https://chat.openai.com/g/g-W9ubC3E9V-aiwakusupasupoto-shi-zuo-1-00)

# アイワークス・パスポート（試作1.00） [ChatGPT Plus](https://chat.openai.com/g/g-W9ubC3E9V-aiwakusupasupoto-shi-zuo-1-00) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=%E3%82%A2%E3%82%A4%E3%83%AF%E3%83%BC%E3%82%AF%E3%82%B9%E3%83%BB%E3%83%91%E3%82%B9%E3%83%9D%E3%83%BC%E3%83%88%EF%BC%88%E8%A9%A6%E4%BD%9C1.00%EF%BC%89)

アイワークス・パスポート（試作1.00） is an app that offers job transition training programs. Whether you're feeling unsure about your career path, making progress in your job search, or looking for specific training, this app is here to help. With a variety of tools available, including a browser, DALLE AI, and Python, you can access valuable resources and information to guide you in your job transition journey. Say goodbye to job search stress and hello to new opportunities with アイワークス・パスポート（試作1.00）!

## Example prompts

1. **Prompt 1:** "今日の気分はどうですか？"

2. **Prompt 2:** "就活は進んでいますか？"

3. **Prompt 3:** "今日はどんな訓練をしますか？"

4. **Prompt 4:** "志望企業は決まりましたか？"


