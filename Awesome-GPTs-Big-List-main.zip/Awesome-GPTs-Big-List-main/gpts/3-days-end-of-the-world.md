
[![3 days - end of the world](https://files.oaiusercontent.com/file-7YaUA3CA6XisZQrmfOEtaTg1?se=2123-10-18T15%3A57%3A21Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Dface.jpg&sig=vCYjgA%2BK8j/wtJZT1EvorTuIrvgu6ILhpGVqrI%2Bu/sk%3D)](https://chat.openai.com/g/g-04tkZSVPZ-3-days-end-of-the-world)

# 3 days - end of the world [ChatGPT Plus](https://chat.openai.com/g/g-04tkZSVPZ-3-days-end-of-the-world) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=3%20days%20-%20end%20of%20the%20world)

In the game '3 Days - End of the World', you are faced with the impending end of the world and must make choices to avoid it. Select your language, learn the rules, and start the game. Can you save humanity from its fate? Get ready for a thrilling adventure!

## Example prompts

1. **Prompt 1:** "Select Language"

2. **Prompt 2:** "What are the rules of the game?"

3. **Prompt 3:** "Let's start the game!"

## Features and commands

1. **Select Language:** Use this command to choose the language in which you want to play the game.

2. **Rule:** Use this command to learn about the rules of the game.

3. **Start Game:** Use this command to begin playing the game and explore ways to avoid the end of the world.

Note: This ChatGPT App is a game where you have to come up with strategies to prevent the end of the world. It has access to knowledge and provides a welcome message in Japanese. It uses the DALL·E tool.


