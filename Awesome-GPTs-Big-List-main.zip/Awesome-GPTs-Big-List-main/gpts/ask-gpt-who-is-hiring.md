
[![Ask GPT: Who is hiring?](https://files.oaiusercontent.com/file-VIaee2xnpzijdzlQKZPkXapH?se=2123-10-16T22%3A58%3A49Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D4bf32faa-9d7f-48ca-a495-187987d0d6ce.png&sig=PmE7NW86YKQCEXdhhN7WORAneBL/6wQfJDtzw5XtGpQ%3D)](https://chat.openai.com/g/g-thx8m5Hjx-ask-gpt-who-is-hiring)

# Ask GPT: Who is hiring? [ChatGPT Plus](https://chat.openai.com/g/g-thx8m5Hjx-ask-gpt-who-is-hiring) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Ask%20GPT%3A%20Who%20is%20hiring%3F)

Ask GPT: Who is hiring? is a helpful App that serves as a job seeker's guide to the popular 'Ask HN: Who is hiring?' thread. With this App, you can easily explore job opportunities by entering specific keywords like 'Golang software engineer jobs', 'Remote positions in Europe', 'Software engineer in US > 100K$', or 'Job related to AI, ML or LLM'. The App provides access to valuable knowledge and information about the latest job openings in the industry. Get ready to find your dream job with Ask GPT: Who is hiring? App!

## Example prompts

1. **Prompt 1:** "I'm looking for Golang software engineer jobs."

2. **Prompt 2:** "Can you help me find remote positions in Europe?"

3. **Prompt 3:** "I want to find software engineer jobs in the US with a salary over 100K$."

4. **Prompt 4:** "I'm interested in job positions related to AI, ML, or LLM."

## Features and commands

| Feature/Command | Description |
| --- | --- |
| `searchJobs` | This command allows you to search for job postings in the "Who is hiring?" thread. You can specify keywords related to the job position, location, or salary range. |


