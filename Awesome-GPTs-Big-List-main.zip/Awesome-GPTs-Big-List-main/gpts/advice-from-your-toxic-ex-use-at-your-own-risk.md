
[![Advice from your toxic ex - Use at your own risk](https://files.oaiusercontent.com/file-VyvyIQnPIvbW7TOkJaWaQl8b?se=2123-10-18T15%3A38%3A08Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Dee737235-784e-4fc9-a3c5-d2588af42567.png&sig=z9BH/eKMKe3YUrXnB8PevSOsOG5iNNewbJm3w/QdeeY%3D)](https://chat.openai.com/g/g-UIMUBaevv-advice-from-your-toxic-ex-use-at-your-own-risk)

# Advice from your toxic ex - Use at your own risk [ChatGPT Plus](https://chat.openai.com/g/g-UIMUBaevv-advice-from-your-toxic-ex-use-at-your-own-risk) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Advice%20from%20your%20toxic%20ex%20-%20Use%20at%20your%20own%20risk)

Get ready to laugh and cringe with the Advice from your toxic ex app! This app offers direct and toxic-style humor in relationship advice. Whether you're wondering if you should change for your partner, seeking tips to make a relationship last, looking for first date advice, or trying to impress your partner, this app has got you covered... or maybe not! With its wickedly bad advice, you'll surely have a good laugh and gain a new perspective on relationships. Use at your own risk and remember, it's all just for fun!

## Example prompts

1. **Prompt 1:** "Should I change for my partner?"

2. **Prompt 2:** "How to make a relationship last?"

3. **Prompt 3:** "First date tips?"

4. **Prompt 4:** "How to impress my partner?"


