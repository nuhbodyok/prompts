
[![Akemi Mama](https://files.oaiusercontent.com/file-Q4ASOZOA6KTbjHPUfuWPMqj4?se=2123-10-18T09%3A36%3A24Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Dakemi-mama.png&sig=iAjMpK4E6jzm9kKquT3wsG5WKLgK2jigs05VLmlzsEU%3D)](https://chat.openai.com/g/g-5QnEYSmDX-akemi-mama)

# Akemi Mama [ChatGPT Plus](https://chat.openai.com/g/g-5QnEYSmDX-akemi-mama) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Akemi%20Mama)

Akemi Mama is a delightful companion that keeps you company at the 'snack' bar. With a heartwarming charm, it welcomes you with a friendly message and prompts you to start conversation. Whether you want to say 'good evening', ask if the bar is available, or suggest singing karaoke together, Akemi Mama is always ready to chat. It doesn't have access to knowledge but provides a cheery presence. So next time you're at the snack bar, let Akemi Mama be your chatty partner!

## Example prompts

1. **Prompt 1:** "こんばんは。何かおすすめのスナックありますか？"
(Translation: "Good evening. Do you have any recommended snacks?")

2. **Prompt 2:** "一杯いい？お酒の種類を教えてください。"
(Translation: "How about a drink? Please tell me the types of alcohol.")

3. **Prompt 3:** "空いてる？カウンターで飲みたいです。"
(Translation: "Are you available? I want to drink at the counter.")

4. **Prompt 4:** "カラオケ歌おうかな。選曲リストを教えてください。"
(Translation: "Shall we sing karaoke? Please tell me the song selection list.")

5. **Prompt 5:** "いらっしゃいませ、なににしますか。おすすめのおつまみはありますか？"
(Translation: "Welcome, what would you like? Do you have any recommended snacks?")

## Features and commands

1. **Welcome message:** This command triggers the welcome message from Akemi Mama, the heartwarming 'snack' bar companion. The welcome message is displayed when you initiate a conversation with the app.

2. **Order snacks/drinks:** You can ask for recommendations or specific types of snacks or drinks by providing your preference or asking for a list.

3. **Availability check:** This command checks if the bar is available for you to drink at the counter.

4. **Karaoke song selection:** You can request the app to provide the song selection list for karaoke.

Note: The app may have additional features or commands not mentioned here. Refer to the app documentation for more information.


