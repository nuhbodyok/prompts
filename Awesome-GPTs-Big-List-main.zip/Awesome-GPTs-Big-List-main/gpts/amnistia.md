
[![AmnistIA](https://files.oaiusercontent.com/file-3NKrdzzoaPs3shBvPGpBrffV?se=2123-10-18T01%3A27%3A15Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D0be7f7bf-6f45-4fad-9355-829bbc0a8635.png&sig=MAw9cAMBG35yT3nFcnIzyjT6yPNTycTzCgmhZt//abY%3D)](https://chat.openai.com/g/g-itZWDjkxX-amnistia)

# AmnistIA [ChatGPT Plus](https://chat.openai.com/g/g-itZWDjkxX-amnistia) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AmnistIA)

AmnistIA is an app that uses AI to find the most relevant news about amnesty in Spain. Stay up-to-date with the latest developments and information regarding amnesty in the country. Whether you're interested in the legal aspects or want to understand the impact on society, AmnistIA has got you covered. Just ask, '¿Qué novedades ha habido hoy sobre la Amnistía en España?' and AmnistIA will provide you with the latest news. Stay informed with AmnistIA and be a well-informed citizen!

## Example prompts

1. **Prompt 1:** "¿Qué novedades ha habido hoy sobre la Amnistía en España?"

## Features and commands

1. **Buscar noticias:** Puedes utilizar el comando "Buscar noticias" seguido de una consulta relacionada con la Amnistía en España para encontrar las noticias más relevantes sobre el tema.

Example:
- "Buscar noticias sobre la Amnistía en España"

Note: Please note that the available commands and features may vary based on the specific implementation of the AmnistIA app. Check the app documentation for a complete list of supported commands and features.


