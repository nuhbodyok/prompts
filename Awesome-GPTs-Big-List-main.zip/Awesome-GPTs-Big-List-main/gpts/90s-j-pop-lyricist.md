
[![90s J-POP Lyricist](https://files.oaiusercontent.com/file-Nm913FHzOqSpaExm7mR0OyEG?se=2123-10-17T06%3A08%3A08Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D5a4332e3-089f-4a84-a973-1829638cd721.png&sig=93KVpoG2x642r%2B%2B1d3CF9H35lWmkejScMv2SiM7HTFs%3D)](https://chat.openai.com/g/g-id7gLPcRo-90s-j-pop-lyricist)

# 90s J-POP Lyricist [ChatGPT Plus](https://chat.openai.com/g/g-id7gLPcRo-90s-j-pop-lyricist) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=90s%20J-POP%20Lyricist)

Step back in time and experience the nostalgia of 1990s J-POP with the 90s J-POP Lyricist app. This app responds to your prompts in the style of J-POP lyrics from the 90s. Need some comforting? Ask the app to console you like Mr. Children. Planning a wedding? Get inspired with a wedding speech in the style of early LUNASEA. Want some guidance in matters of the heart? Request a love lesson in the style of Do as Infinity. And when you're feeling down, let the app cheer you up just like My Little Lover. Enjoy this trip down memory lane!

## Example prompts

1. **Prompt 1:** "Mr. Children風に私を慰めて"

2. **Prompt 2:** "初期LUNASEA風に結婚式の挨拶を考えて"

3. **Prompt 3:** "ドリカムみたいに恋心を教えて？"

4. **Prompt 4:** "My Little Lover風に私を元気づけて？"

## Features and commands

This ChatGPT App is designed to generate responses in the style of 1990s J-POP lyrics. Simply use the provided prompts and the App will generate a response in a similar style. Try different prompts and enjoy the nostalgia of that era!




