
[![Artie's Adventure Magic](https://files.oaiusercontent.com/file-KaNM2v7h3fooSAHi1dFBcInN?se=2123-10-17T15%3A09%3A36Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D3a955eb8-c566-4cb3-aa9a-78ab9c424cb7.png&sig=omOSSlTeVTHRKzelC3pc%2B4/shQH0AclJ6w7jKXT9F%2BY%3D)](https://chat.openai.com/g/g-nHE5NrELQ-artie-s-adventure-magic)

# Artie's Adventure Magic [ChatGPT Plus](https://chat.openai.com/g/g-nHE5NrELQ-artie-s-adventure-magic) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Artie's%20Adventure%20Magic)

Artie's Adventure Magic is an AI-powered storyteller app that brings stories to life with unique illustrations. With every story segment, Artie's Adventure Magic uses its AI technology to create a new illustration that enhances the narrative. Whether it's a scene where a dragon meets a wizard or a choice for the child to decide if the dragon should befriend the wizard, Artie's Adventure Magic sparks imagination and engagement. Step into a world where stories come alive through captivating illustrations!

## Example prompts

1. **Prompt 1:** "Tell me a story where 孙悟空 goes to rescue 哆啦A梦."

2. **Prompt 2:** "Can you draw a scene with a dragon meeting a wizard?"

3. **Prompt 3:** "Give me two options: should the dragon befriend the wizard or not?"

4. **Prompt 4:** "Continue the story after the dragon and wizard meet and go on an adventure."

5. **Prompt 5:** "What happens next in the story after the dragon meets the wizard?"

## Features and commands

- `孙悟空去拯救哆啦A梦的故事`: This command generates a story where 孙悟空 goes on a mission to rescue 哆啦A梦.

- `Draw a scene where a dragon meets a wizard.`: This command instructs the AI to create an illustration depicting a dragon meeting a wizard.

- `Offer a choice for the child: should the dragon befriend the wizard?`: This command prompts the AI to provide two options for the child to choose from regarding the friendship between the dragon and the wizard.

- `Complete the story where the dragon and wizard go on an adventure.`: This command asks the AI to continue the story after the dragon and wizard meet, taking them on an adventure.

- `Continue the story after the dragon meets the wizard.`: This command instructs the AI to continue the story from the point where the dragon meets the wizard.


