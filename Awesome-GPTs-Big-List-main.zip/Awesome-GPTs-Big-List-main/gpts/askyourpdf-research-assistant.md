
[![AskYourPDF Research Assistant](https://github.com/AskYourPdf/ask-plugin/blob/main/aypp_logo.png?raw=true)](https://chat.openai.com/g/g-UfFxTDMxq-askyourpdf-research-assistant)

# AskYourPDF Research Assistant [ChatGPT Plus](https://chat.openai.com/g/g-UfFxTDMxq-askyourpdf-research-assistant) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AskYourPDF%20Research%20Assistant)

Enhance your research with the AskYourPDF Research Assistant. Chat with multiple files, generate articles with citations, analyze and generate references for papers, create and interact with a knowledge base of your files and much more.

## Example prompts

1. **Prompt 1:** "Write me an essay on the effects of Large Language Models such as ChatGPT on education."

2. **Prompt 2:** "Tell me about the following research https://arxiv.org/pdf/2306.12338.pdf."

3. **Prompt 3:** "List the documents on my account."

4. **Prompt 4:** "Make a table of the key contributions."

## Features and commands

1. **Upload Pdf:** Upload a PDF file and save it to the database.

2. **Download Pdf:** Download a PDF file from a URL and save it to the vector database.

3. **Perform Query on Document or Knowledge base using id:** Perform a query on a document.

4. **Get References:** Retrieve a list of references that match the specified criteria.

5. **Fetch User Documents:** Returns all documents for the current user. Request maximum 10 documents per page.

6. **Create Knowledge Base:** Create a knowledge base from a list of document IDs.

7. **Update Knowledge Base:** Update a knowledge base from a list of document IDs.

8. **Delete Knowledge Base:** Delete a knowledge base.

9. **Search for documents:** Search for documents based on a search query.

10. **Get Knowledge Bases:** Get knowledge bases.

11. **Search Knowledge Bases:** Search knowledge bases based on a search query.

Note: Some commands may require additional arguments or parameters that are not specified in the prompt. Please refer to the App documentation for more details on command usage.


