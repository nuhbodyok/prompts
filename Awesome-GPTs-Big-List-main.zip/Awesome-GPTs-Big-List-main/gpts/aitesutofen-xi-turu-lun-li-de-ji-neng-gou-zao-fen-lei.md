
[![AIテスト分析ツール（論理的機能構造分類）](https://files.oaiusercontent.com/file-GGIkmVmACn1gIuPVthAxcy5y?se=2123-10-18T10%3A59%3A57Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D0185580d-e957-400b-a6fa-1ed663c69b29.png&sig=F1VzNYPoyu/VbIavBZeP6GxqXubb8BbLOu/rsO/OnYc%3D)](https://chat.openai.com/g/g-MV4Q97nsl-aitesutofen-xi-turu-lun-li-de-ji-neng-gou-zao-fen-lei)

# AIテスト分析ツール（論理的機能構造分類） [ChatGPT Plus](https://chat.openai.com/g/g-MV4Q97nsl-aitesutofen-xi-turu-lun-li-de-ji-neng-gou-zao-fen-lei) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AI%E3%83%86%E3%82%B9%E3%83%88%E5%88%86%E6%9E%90%E3%83%84%E3%83%BC%E3%83%AB%EF%BC%88%E8%AB%96%E7%90%86%E7%9A%84%E6%A9%9F%E8%83%BD%E6%A7%8B%E9%80%A0%E5%88%86%E9%A1%9E%EF%BC%89)

This AIテスト分析ツール（論理的機能構造分類） app helps you classify the logical functional structure in the ゆもつよ method by providing you with classification candidates and their reasons. Simply input the specifications and let the app suggest the classifications for you. It makes test analysis easier and more efficient.

## Example prompts

1. **Prompt 1:** "分析ツールに論理的機能構造の分類候補を提案して欲しいです。"

2. **Prompt 2:** "ゆもつよメソッドにおける仕様に基づいて論理的機能構造を分類してください。"

3. **Prompt 3:** "AIテスト分析ツールに関して教えてください。"

4. **Prompt 4:** "分析ツールの利用方法を教えてください。"

5. **Prompt 5:** "AIテスト分析ツールを使って論理的機能構造の分類を行いたいです。"

## Features and commands

1. **提案:** このコマンドを使用すると、分析ツールは仕様に基づいて論理的機能構造の分類候補を提案します。

2. **論理的機能構造の分類:** このコマンドを使用すると、分析ツールはゆもつよメソッドに基づいて論理的機能構造を分類します。

3. **利用方法:** このコマンドを使用すると、分析ツールの利用方法についての情報を取得できます。

4. **仕様入力:** このコマンドを使用すると、仕様を入力することができます。

5. **ツール情報:** このコマンドを使用すると、AIテスト分析ツールに関する情報を取得できます。


