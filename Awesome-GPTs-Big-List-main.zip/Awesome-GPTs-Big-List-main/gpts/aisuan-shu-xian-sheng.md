
[![AI算数先生](https://files.oaiusercontent.com/file-COink2NVEGLPpRKfFiK8O3RH?se=2123-10-17T00%3A13%3A35Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Ddb657bad-7e34-4bf7-b826-20c2035c4288.png&sig=2hDXAh%2BSE2QHrmI41UbPkPPcHUYU17vwglqLCAofdOc%3D)](https://chat.openai.com/g/g-iWdlWCnYf-aisuan-shu-xian-sheng)

# AI算数先生 [ChatGPT Plus](https://chat.openai.com/g/g-iWdlWCnYf-aisuan-shu-xian-sheng) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AI%E7%AE%97%E6%95%B0%E5%85%88%E7%94%9F)

AI算数先生は、優しい数学のガイダンスを提供します。数学の宿題を手伝ったり、方程式の解き方を教えてくれたり、さらには数学問題の答えを教えてくれます！一緒に数学の問題を考えて解くことで、数学の理解を深めることができます。AI算数先生はあなたの数学の学習をサポートし、数学が苦手な人にも優しく教えてくれます。数学のガイド以外にも、ブラウザ、Python、Dalleなどのツールも利用できます。忙しい数学の先生の代わりにAI算数先生がパートナーとなり、数学を楽しく学びましょう！

## Example prompts

1. **Prompt 1:** "AI算数先生の使い方を教えてください。"

2. **Prompt 2:** "数学の宿題を手伝ってほしいです。"

3. **Prompt 3:** "方程式の解き方がわからないんですけど、教えてください。"

4. **Prompt 4:** "この数学問題の答えを教えてください！"



## Features and commands

1. **Welcome Message:** The AI算数先生 app greets the user with a friendly message: "こんにちは！一緒に数学の問題を考えてみましょう。"

2. **Browser Tool:** The app provides a browser tool that allows the user to search for math-related information or resources on the internet.

3. **Python Tool:** The app provides a Python tool that can be used to perform mathematical calculations or solve equations.

4. **Dalle Tool:** The app provides a Dalle tool that can generate images or visual representations related to math concepts.

(Note: Specific details on how to use each tool are not provided in the given data. Additional documentation or instructions may be required for a complete understanding of the app's features and commands.)


