
[![あんはるのアイコンジェネレーター](https://files.oaiusercontent.com/file-o22SLwwAeuubbK2AwrSqTinx?se=2123-10-17T05%3A33%3A05Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3DDALL%25C2%25B7E%25202023-11-10%252011.48.10%2520-%2520Illustration%2520of%2520a%2520young%2520Korean%2520woman%2520with%2520a%2520serene%2520and%2520gentle%2520look.%2520Her%2520blue-black%2520hair%2520cascades%2520down%252C%2520and%2520her%2520bangs%2520frame%2520her%2520face.%2520She%2520possesses%2520dou.png&sig=gj0tXszNfORQbjZ53428fh0ghtzY8gZeHY9M0l20kOU%3D)](https://chat.openai.com/g/g-AXfj2P2Lq-anharunoaikonzienereta)

# あんはるのアイコンジェネレーター [ChatGPT Plus](https://chat.openai.com/g/g-AXfj2P2Lq-anharunoaikonzienereta) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=%E3%81%82%E3%82%93%E3%81%AF%E3%82%8B%E3%81%AE%E3%82%A2%E3%82%A4%E3%82%B3%E3%83%B3%E3%82%B8%E3%82%A7%E3%83%8D%E3%83%AC%E3%83%BC%E3%82%BF%E3%83%BC)

あんはるのアイコンジェネレーター is an App that helps you create customized face icons. Whether you want a blue-haired girl, a blonde gal, or a gentle expression, this App has got you covered! It even allows you to design icons with plenty of white space. Get creative and design unique icons to use in your chats and messages. With its user-friendly tools and intuitive interface, designing your own icons has never been easier. So, let's get started and create some amazing face icons together!

## Example prompts

1. **Prompt 1:** "Can you generate an icon of a woman with blue hair?"

2. **Prompt 2:** "I want an icon of a girl with blond hair, something like a gal."

3. **Prompt 3:** "Please design an icon with a gentle expression."

4. **Prompt 4:** "Could you illustrate an icon with a lot of white space?"

## Features and commands

- `generate an icon of a woman with blue hair`: This command generates an icon image of a woman with blue hair.
- `generate an icon of a girl with blond hair, something like a gal`: This command generates an icon image of a girl with blond hair, resembling a gal.
- `design an icon with a gentle expression`: This command creates an icon image with a gentle expression.
- `illustrate an icon with a lot of white space`: This command produces an icon image with a large amount of white space.


