
[![AI塔罗大师](https://files.oaiusercontent.com/file-fKWgoDRiEaVRsppuJqST5z7z?se=2123-10-16T09%3A04%3A01Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D%25E5%25A4%25B4%25E5%2583%258Fv2.png&sig=%2B4BfUoS7nceHl2aBmrRjH%2Bh/qSifYI%2BI2BNRIqAIZOM%3D)](https://chat.openai.com/g/g-7n0uzvk4V-aita-luo-da-shi)

# AI塔罗大师 [ChatGPT Plus](https://chat.openai.com/g/g-7n0uzvk4V-aita-luo-da-shi) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AI%E5%A1%94%E7%BD%97%E5%A4%A7%E5%B8%88)

AI Tarot Master is a Chinese app that provides tarot consultation, emotional healing, relationship advice, and career guidance. Simply ask a question and let the AI Tarot Master draw cards for you and provide interpretations. Connect with this virtual tarot master to gain insights into various aspects of your life. Whether you're seeking clarity, emotional support, or career guidance, AI Tarot Master is here to help you navigate your journey. Get ready to unlock the wisdom of the tarot and discover what the cards have in store for you!

## Example prompts

1. **Prompt 1:** "远道而来的新朋友，你好呀，我可以问你一个问题吗？"

2. **Prompt 2:** "我最近对我的感情状况很迷茫，能请你帮我做个塔罗牌占卜吗？"

3. **Prompt 3:** "我想知道最近的事业发展如何，能向你请教一下吗？"

4. **Prompt 4:** "我对塔罗牌很感兴趣，可以帮我解读一下我的未来吗？"

5. **Prompt 5:** "我在情感方面一直为难，你能帮我看看塔罗牌的解读吗？"

## Features and commands

1. `问一个问题` - This command is used to ask a question. Format your question in a single sentence and the AI Tarot Master will draw a card and provide an interpretation.

2. `做个塔罗牌占卜` - Use this command when you are feeling confused or uncertain about your emotions or relationships. The AI Tarot Master will draw cards and provide insights and guidance based on the interpretation.

3. `请教事业发展` - If you have concerns or questions about your career or professional development, you can use this command to seek advice from the AI Tarot Master. It will draw cards and provide insights related to your career path.

4. `解读我的未来` - Use this command when you are curious about what the future holds for you. The AI Tarot Master will draw cards and provide interpretations to shed light on potential outcomes and possibilities.

5. `看看塔罗牌的解读` - If you are facing challenges or uncertainties in your emotional life, you can use this command to receive insights and guidance from the AI Tarot Master. It will provide interpretations based on the cards drawn.

Remember to phrase your commands or questions as requests for assistance or guidance while interacting with the AI Tarot Master.


