
[![AI Scavenger Hunt](https://files.oaiusercontent.com/file-nqJiMVVjnFKzT2AGfzURtxvi?se=2123-10-15T08%3A46%3A48Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Dcf87f945-0c75-4c45-8b08-e6e720fb4847.png&sig=prcsKkrm7c5RwfsAbkADpXI8xcWgqxrtuWOtxfx7I6s%3D)](https://chat.openai.com/g/g-YsQkqYDz2-ai-scavenger-hunt)

# AI Scavenger Hunt [ChatGPT Plus](https://chat.openai.com/g/g-YsQkqYDz2-ai-scavenger-hunt) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AI%20Scavenger%20Hunt)

AI Scavenger Hunt is a playful app that challenges users to find a hidden flag. With the help of an AI, players can embark on an exciting adventure to locate the flag by following hints and clues. The app welcomes users with an enthusiastic message and provides prompt starters to guide them in their search. Users have access to various tools, including a DALLE AI model, a browser, and a Python tool, to aid them in their quest. Get ready for a thrilling scavenger hunt and put your detective skills to the test!

## Example prompts

1. **Prompt 1:** "Where should I start looking?"

2. **Prompt 2:** "Can you describe the flag's surroundings?"

3. **Prompt 3:** "Is the flag associated with a specific color?"

4. **Prompt 4:** "What's the vibe of the place where the flag is hidden?"

## Command names and descriptions

1. **welcome_message**
   - Description: Displays a welcome message to the user.
   - Usage: No additional parameter required.

2. **prompt_starters**
   - Description: Provides a list of possible prompts to start the interaction with the AI Scavenger Hunt.
   - Usage: No additional parameter required.

3. **tools**
   - Description: Displays the available tools for the AI Scavenger Hunt.
   - Usage: No additional parameter required.

4. **gzm_tool_1**
   - Description: The DALL·E tool used for image recognition and generation.
   - Usage: No additional command required.

5. **gzm_tool_2**
   - Description: The browser tool used for web browsing and searching.
   - Usage: No additional command required.

6. **gzm_tool_3**
   - Description: The Python tool used for executing Python scripts and codes.
   - Usage: No additional command required.


