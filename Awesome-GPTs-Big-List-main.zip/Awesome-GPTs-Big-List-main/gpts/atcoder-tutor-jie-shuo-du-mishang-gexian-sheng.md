
[![AtCoder Tutor - 解説読み上げ先生](https://files.oaiusercontent.com/file-pG5CLnFh5Pslr0poKJQKfLNe?se=2123-10-18T06%3A59%3A27Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Datcoder-tutor-logo.webp&sig=/kWek554Pu/b/tj1yk0hAFnmYCy5LOfyHr4IeijVZfQ%3D)](https://chat.openai.com/g/g-NQBui8UaX-atcoder-tutor-jie-shuo-du-mishang-gexian-sheng)

# AtCoder Tutor - 解説読み上げ先生 [ChatGPT Plus](https://chat.openai.com/g/g-NQBui8UaX-atcoder-tutor-jie-shuo-du-mishang-gexian-sheng) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AtCoder%20Tutor%20-%20%E8%A7%A3%E8%AA%AC%E8%AA%AD%E3%81%BF%E4%B8%8A%E3%81%92%E5%85%88%E7%94%9F)

AtCoder Tutor is your personal assistant when it comes to understanding AtCoder problem statements and explanations. Simply provide the problem statement and explanation, and AtCoder Tutor will read them out loud to you, guiding you through the process. No more struggling with understanding the details on your own! Whether you're a beginner or an experienced coder, AtCoder Tutor ensures that you never miss out on important details. Get ready to level up your AtCoder skills with the help of this knowledgeable and supportive tutor!

## Example prompts

1. **Prompt 1:** "AtCoderの問題文と解説を今からあなたに送ります。"

2. **Prompt 2:** "AtCoderの問題文と解説を教えてください。"

3. **Prompt 3:** "解説を読んでほしい問題文を教えてください。"

4. **Prompt 4:** "AtCoderの問題文と解説を教えて欲しいです。"

5. **Prompt 5:** "解説が欲しい問題文を探しています。"

## Features and commands

1. **Read explanation:** You can provide the problem statement and explanation of an AtCoder question and the app will read it along with you.

2. **Get problem statement:** You can ask for the problem statement and explanation of an AtCoder question.

3. **Provide question statement and explanation:** You can send the problem statement and explanation to the app for it to read along with you.


