
[![Anime Archive Aide](https://files.oaiusercontent.com/file-EdsrGTMMWn4l4eAlWi23Kjhs?se=2123-10-17T03%3A28%3A07Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Db4008e2d-110c-447c-bf5a-1be0d51f4be8.png&sig=h5U6cueG7FO6tjfNlKZWwUHsILiR%2BmLjliCnV1ZK8aU%3D)](https://chat.openai.com/g/g-bBragyjhF-anime-archive-aide)

# Anime Archive Aide [ChatGPT Plus](https://chat.openai.com/g/g-bBragyjhF-anime-archive-aide) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Anime%20Archive%20Aide)

Anime Archive Aide is your go-to expert for classifying and finding information about anime. With this app, you can easily search for specific genres and years of release, making it a breeze to find your favorite mecha, romance, sports, and fantasy anime. Just ask Anime Archive Aide questions like 'List all mecha anime in 2005' or 'Find fantasy anime released in 2018', and it will provide you with a comprehensive list of anime titles. Explore the world of anime with Anime Archive Aide, your trusty anime classification expert!

## Example prompts

1. **Prompt 1:** "List all mecha anime in 2005."

2. **Prompt 2:** "What romance anime aired in 2010?"

3. **Prompt 3:** "Show the sports anime from 2000-2022."

4. **Prompt 4:** "Find fantasy anime released in 2018."

## Features and commands

1. **List all mecha anime in 2005:** This command will list all the mecha anime that were aired in the year 2005.

2. **What romance anime aired in 2010?:** This command will provide information about the romance anime that were aired in the year 2010.

3. **Show the sports anime from 2000-2022:** This command will display a list of sports anime that were aired between the years 2000 and 2022.

4. **Find fantasy anime released in 2018:** This command will search and provide a list of fantasy anime that were released in the year 2018.


