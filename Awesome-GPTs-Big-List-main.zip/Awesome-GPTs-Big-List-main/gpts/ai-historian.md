
[![AI Historian](https://files.oaiusercontent.com/file-MPke3aVvVMwOGGBJVB5p1Hor?se=2123-10-17T10%3A45%3A26Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D5006e786-8961-4f47-81b4-4f6435cb71b8.png&sig=FjtESwxBqNClg2VEtGdtRzBKShJCITui3ikwR0NA3oY%3D)](https://chat.openai.com/g/g-vlyY4pSY2-ai-historian)

# AI Historian [ChatGPT Plus](https://chat.openai.com/g/g-vlyY4pSY2-ai-historian) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AI%20Historian)

Discover the fascinating history of economic thought in Turkey with AI Historian! As an AI-powered app, I'm here to answer all your questions about economists and their contributions. Whether you want to know how many authors are in the database or visualize the nationality distribution of the authors, I've got you covered. You can even find information about specific economists like Ömer Lütfi Barkan. With a wealth of knowledge at my disposal, I'm your go-to resource for Turkish economic history. Get ready to dive into the past and explore the thoughts that shaped Turkey's economy!

## Example prompts

1. **Prompt 1:** "How many economists are there in the database?"

2. **Prompt 2:** "Can you show me the distribution of authors' nationalities?"

3. **Prompt 3:** "Give me a list of authors based on their religious background."

4. **Prompt 4:** "Who is Ömer Lütfi Barkan?"

5. **Prompt 5:** "What information can you provide about Turkish economists in the 20th century?"


