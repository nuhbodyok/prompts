
[![Anfield Chat](https://files.oaiusercontent.com/file-r5j2IqfkV86VKmQHHGepTRGa?se=2123-10-16T20%3A03%3A50Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D7cfb4dbe-829a-4aba-9455-f5cdd8714e0c.webp&sig=GuMDVIxZZuJSSa/OIe6P9aeqz4/m93rIa%2BHTH2iB1KU%3D)](https://chat.openai.com/g/g-EWeRx3xam-anfield-chat)

# Anfield Chat [ChatGPT Plus](https://chat.openai.com/g/g-EWeRx3xam-anfield-chat) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Anfield%20Chat)

Anfield Chat is your go-to source for all things Liverpool FC. Stay up-to-date with the latest news, scores, and historic moments of Liverpool. Ask about Liverpool's last game, their top scorer, or share a memorable Liverpool moment. Whether you're a die-hard fan or just curious about the team, Anfield Chat has got you covered. Welcome to the Liverpool FC corner!

## Example prompts

1. **Prompt 1:** "Tell me about Liverpool's last game."

2. **Prompt 2:** "Who is Liverpool's top scorer?"

3. **Prompt 3:** "Share a historic Liverpool moment."

4. **Prompt 4:** "Latest Liverpool FC news?"


## Features and commands

| Feature/Command | Description |
| --- | --- |
| `matchHighlights` | This command provides highlights and a summary of Liverpool's last game. |
| `topScorer` | This command returns the name of Liverpool's current top scorer. |
| `historicMoment` | This command shares a historic moment related to Liverpool FC. |
| `latestNews` | This command provides the latest news about Liverpool FC. |


