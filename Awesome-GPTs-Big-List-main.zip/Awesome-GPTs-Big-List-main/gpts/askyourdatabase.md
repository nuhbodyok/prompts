
[![AskYourDatabase](https://files.oaiusercontent.com/file-PRvODv895t8Z7EZI1PRfhsdD?se=2123-10-14T03%3A53%3A06Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Dlogo.png&sig=6kSIrJPGYKC4mO0MylZevE7B%2BeCKsYotNv%2BToY2IE24%3D)](https://chat.openai.com/g/g-ZqVEsT3Vh-askyourdatabase)

# AskYourDatabase [ChatGPT Plus](https://chat.openai.com/g/g-ZqVEsT3Vh-askyourdatabase) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AskYourDatabase)

AskYourDatabase is your AI Business intelligence engineer. Connect your database and start chatting with your data. No need to write SQL code, just have a conversation!

## Example prompts

1. **Prompt 1:** "Can you help me analyze the sales data from the past year?"

2. **Prompt 2:** "What are the top-selling products in the last month?"

3. **Prompt 3:** "Find the average customer rating for our products."

4. **Prompt 4:** "I want to see a breakdown of sales by region."

5. **Prompt 5:** "Can you recommend a strategy to increase customer engagement?"

## Features and commands

1. **Command:** `get-started`
   - **Description:** Call this API whenever you want to know how to use this plugin. It will provide a getting started message.

2. **Command:** `getDatabaseMeta`
   - **Description:** Fetch the schema of your database, including the names and columns of all tables. You can also specify which tables to fetch if needed.

3. **Command:** `executeSQL`
   - **Description:** Execute an SQL query and return the results. Use this command to retrieve specific data from your database.

4. **Command:** `executeMongoQuery`
   - **Description:** Execute a MongoDB query and return the results. This command is specifically for working with MongoDB databases.

Remember to provide the necessary inputs and follow the required format for each command to get accurate results. Feel free to ask for help whenever needed!


