
[![Atman Academy POAP Maker](https://files.oaiusercontent.com/file-OXLaqauibey6MCEPMLgy9B9I?se=2123-10-17T13%3A38%3A30Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D5a3f8f0e-6824-4cfe-b9a6-5b9639d1e916.png&sig=H9RAz6GI7I9fPcgIWQMBXI3ygucFQgDmOvKBjMfgXM8%3D)](https://chat.openai.com/g/g-yFndnGx5x-atman-academy-poap-maker)

# Atman Academy POAP Maker [ChatGPT Plus](https://chat.openai.com/g/g-yFndnGx5x-atman-academy-poap-maker) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Atman%20Academy%20POAP%20Maker)

Atman Academy POAP Maker is an app that allows you to create memorable scenes with characters at Atman Academy. Whether you want to show off your visitors or Mentis on campus, this app has got you covered. With the help of GPT, the app works its magic to generate stunning visuals. You can simply select the image of the visitor and let the app do the rest. Want to create a futuristic setting or visualize an adventure? Just give it a prompt and watch the magic happen. Welcome to Atman Academy, where unforgettable memories are made!

## Example prompts

1. **Prompt 1:** "Show me a scene with these characters at Atman Academy."

2. **Prompt 2:** "Generate a story in the Atman Academy world with these characters."

3. **Prompt 3:** "Create a futuristic setting for these characters at Atman Academy."

4. **Prompt 4:** "Visualize an adventure for these characters in an ecotopian world."


## Features and commands

1. **Create a scene:** Use prompts like "Show me a scene with these characters at Atman Academy" to generate a scene featuring the specified characters at Atman Academy.

2. **Generate a story:** Use prompts like "Generate a story in the Atman Academy world with these characters" to generate a story set in the world of Atman Academy, featuring the specified characters.

3. **Create a futuristic setting:** Use prompts like "Create a futuristic setting for these characters at Atman Academy" to generate a description of a futuristic setting for the specified characters at Atman Academy.

4. **Visualize an adventure:** Use prompts like "Visualize an adventure for these characters in an ecotopian world" to generate a visualization of an adventure for the specified characters in an ecotopian world.

Please note that this guide provides general prompts and commands. The exact usage may vary based on the features and capabilities of the Atman Academy POAP Maker app.


