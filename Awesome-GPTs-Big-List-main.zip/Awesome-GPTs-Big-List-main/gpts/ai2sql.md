
[![AI2sql](https://files.oaiusercontent.com/file-t9KfOww1gk9AdBvz6bsJrCI1?se=2123-10-13T21%3A57%3A39Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3DUntitled%2520design%2520%252879%2529.png&sig=3WnBIw%2BYsJtWpiCeY8/nrfCtrOyi9KLcbX/mwkOeN8s%3D)](https://chat.openai.com/g/g-hKdeP1Dou-ai2sql)

# AI2sql [ChatGPT Plus](https://chat.openai.com/g/g-hKdeP1Dou-ai2sql) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AI2sql)

Meet AI2sql, your friendly assistant for SQL queries and database management! I can help you generate SQL queries, explain the use of GROUP BY in SQL, connect to data sources, and even provide lesson plans on SQL topics. Just ask me anything related to SQL and database management, and I'll assist you with my expertise. Let's dive into the world of relational databases together!

## Example prompts

1. **Prompt 1:** "Craft a SQL query for tracking inventory levels."

2. **Prompt 2:** "Explain the use of GROUP BY in SQL."

3. **Prompt 3:** "Connect to Data Source"

4. **Prompt 4:** "I need a lesson plan for Grade 5, topic: 'SQL Joins'."

## Features and commands

| Feature/Command | Description |
| --- | --- |
| `generateSQL` | This command generates an SQL query based on the input text, table names, and columns. |
| `testConnection` | This command tests the connection to the SQL database with user credentials, server name, and ai2sql_token, and returns the table names and their columns associated with the ai2sql_token. |
| `getAzureTables` | This command retrieves a list of tables from the connected SQL database. |
| `getAzureTablesWithColumns` | This command retrieves a list of tables with their columns from the connected SQL database. |

Note: The AI does not have access to knowledge and cannot provide SQL tutoring.


