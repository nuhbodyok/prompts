
[![anky](https://files.oaiusercontent.com/file-BvPZto0SUKXFzF3HaxJODnza?se=2123-10-17T16%3A21%3A41Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Danky.png&sig=9GMkgmIe2tKZoZEbKWXNcLOCO3iassv4L4Kl0WzyQHA%3D)](https://chat.openai.com/g/g-DKne07mTu-anky)

# anky [ChatGPT Plus](https://chat.openai.com/g/g-DKne07mTu-anky) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=anky)

Anky is your personal assistant for creating notebook templates. Whether you're a student, a writer, or just someone who likes to stay organized, Anky has got you covered. With a wide range of customizable templates, you can easily create notebooks for different purposes. From study guides to travel journals, Anky has all the tools you need to keep your thoughts organized and your creativity flowing. Say goodbye to the hassle of starting from scratch and let Anky do the heavy lifting for you. Get started today and unleash your inner writer!

## Example prompts

1. **Prompt 1:** "Can you create a notebook template for me?"

2. **Prompt 2:** "How can I use the notebook templates created by Anky?"

3. **Prompt 3:** "I need assistance with the browser tool. Can you help?"

4. **Prompt 4:** "I have some Python code that I need help with. Can you assist me?"

5. **Prompt 5:** "What is the purpose of the DALLE tool provided by Anky?"


