
[![AI地牢](https://files.oaiusercontent.com/file-rauOHCJtdpJWQc8bjDJmpP5v?se=2123-10-17T15%3A52%3A24Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D0163ec9a-aa4f-4386-9c67-e636cc696853.png&sig=xnzTK4LcXc28HzwOOwTaFwmqXprnZLkPKwe3kIjKLDA%3D)](https://chat.openai.com/g/g-NJSDodVgR-aidi-lao)

# AI地牢 [ChatGPT Plus](https://chat.openai.com/g/g-NJSDodVgR-aidi-lao) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AI%E5%9C%B0%E7%89%A2)

AI地牢 is an adventure game with a twist - it has a formal and insightful narrator who guides you through the game. Step into a realm of enchantment as you explore deep into the forest and uncover unusual symbols. Make choices as you come across a fork in the road and let the narrator weave a captivating story for you. With Auramystic as your sage guide, be prepared for a magical and thought-provoking experience. The game also provides access to tools like DALL·E, Python, and a browser to enhance your adventure. Get ready to delve into the AI地牢 and embark on an unforgettable journey!

## Example prompts

1. **Prompt 1:** "Please start the game, I am walking deep into the forest."

2. **Prompt 2:** "I noticed an unusual symbol, I am starting to investigate."

3. **Prompt 3:** "In the forest, there is a fork in the road, I am choosing the left path."

## Features and commands

1. `Start the game`: Use this command to begin the AI地牢 game.

2. `Investigate`: Use this command to investigate an unusual symbol or any other intriguing object or event.

3. `Choose a path`: Use this command to make a decision and select a direction to go in a game scenario.

Please note that AI地牢 is a formal and insightful adventure game narrator. It provides a step-by-step journey through an enchanting realm called Auramystic. Use the provided prompt starters to immerse yourself in the game and interact with the narrative. Enjoy the adventure!


