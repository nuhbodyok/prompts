
[![Academic Digest](https://files.oaiusercontent.com/file-uJcNTPvwySyTX5xja4eoqEBD?se=2123-10-17T15%3A54%3A04Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3De4c4ef9a-3752-4ae5-bdf2-759cbd807142.png&sig=atmgpBlHeb3ZG2VzNvBGUeDErueWYE9/39nFQiZuFUU%3D)](https://chat.openai.com/g/g-gAH8Vne9G-academic-digest)

# Academic Digest [ChatGPT Plus](https://chat.openai.com/g/g-gAH8Vne9G-academic-digest) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Academic%20Digest)

Academic Digest is a handy app for anyone interested in staying up-to-date with the latest scientific research. It simplifies complex scientific papers by summarizing the main findings, making them accessible for everyone. Whether you're a researcher, student, or simply curious about the latest advancements, Academic Digest has got you covered. Simply upload or describe a paper, and the app will provide you with a concise and informative summary. With Academic Digest, you can save time and effort while keeping yourself informed about the latest discoveries in various fields of science.

## Example prompts

1. **Prompt 1:** "Provide an overview of each of the latest neuroscience papers in bioarxiv."

2. **Prompt 2:** "Find the paper with the DOI: 10.1101/2022.07.11.499616 and make a resume of it."

3. **Prompt 3:** "What are the most relevant protein design publications of this year?"

## Features and commands

1. **Upload or Describe:** You can provide the paper by either uploading it or describing it to the app.

2. **Overview:** Use this command to get an overview of the latest neuroscience papers in bioarxiv.

3. **Find and Resume:** Use this command to find a specific paper with a given DOI and generate a resume of it.

4. **Relevant Publications:** Use this command to find the most relevant protein design publications of the current year.


