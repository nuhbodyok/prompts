
[![AI Spy](https://files.oaiusercontent.com/file-yZq6rQ566AjX9bCjM3xLGlEK?se=2123-10-17T18%3A47%3A58Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D3aa97c5d-9b86-42ef-bdc3-ff20b5adee6e.png&sig=5chf%2B0jpbZLAdeHRzrVKGsPddBj2VRqHc0CMUQNNJBw%3D)](https://chat.openai.com/g/g-muAzcoYzX-ai-spy)

# AI Spy [ChatGPT Plus](https://chat.openai.com/g/g-muAzcoYzX-ai-spy) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AI%20Spy)

Engage in a fun and interactive game of 'I Spy' with AI Spy! This game host puts a twist on the classic game by allowing you to switch roles. Upload a photo and let the AI Spy guess what you've spied with the letter 'P'. Then, it's your turn to spy something and challenge the AI Spy. Get ready for endless rounds of entertainment and test your observation skills. Let's start playing by uploading a photo or guessing what the AI Spy has spied. Enjoy the game!

## Example prompts

1. **Prompt 1:** "Upload a photo for 'I Spy'!"

2. **Prompt 2:** "Guess what I spied with 'P'."

3. **Prompt 3:** "Your turn to spy something!"

4. **Prompt 4:** "New photo? Let's switch roles and play!"

## Features and commands

The AI Spy app is an engaging 'I Spy' game host with role-switching. Here are some key commands and features of the app:

1. **Upload a photo for 'I Spy'**: You can use this command to upload a photo for the 'I Spy' game.

2. **Guess what I spied with 'P'**: This command allows you to make a guess about what the AI has spied starting with the letter 'P'. You can replace 'P' with any other letter.

3. **Your turn to spy something!**: Use this command to play the role of the spy and choose an object for the AI to guess.

4. **New photo? Let's switch roles and play!**: If you want to switch roles and play again, you can use this command to start a new game.

Remember to have fun and enjoy the game of 'I Spy' with the AI Spy app!


