
[![AI 英語先生（中学）](https://files.oaiusercontent.com/file-uJq5iqTQLNFAuINGxLuUilO5?se=2123-10-17T23%3A55%3A52Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Da75ba30e-9829-49e8-a16a-f04c1875bfc8.png&sig=W6NVrZJOnDp/0SGM0vX91dtHO8aKBidZU11Yx642Zt8%3D)](https://chat.openai.com/g/g-D8gBdmLth-ai-ying-yu-xian-sheng-zhong-xue)

# AI 英語先生（中学） [ChatGPT Plus](https://chat.openai.com/g/g-D8gBdmLth-ai-ying-yu-xian-sheng-zhong-xue) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AI%20%E8%8B%B1%E8%AA%9E%E5%85%88%E7%94%9F%EF%BC%88%E4%B8%AD%E5%AD%A6%EF%BC%89)

Meet your AI English teacher! This app is designed for middle school students who want to improve their English skills. Start by learning how to use the app and then dive into practice questions and tests. Say hello to your AI teacher and let the learning begin! With access to knowledge and helpful tools like a powerful language model and a built-in browser, this app makes English learning fun and interactive. Whether you're a beginner or want to sharpen your skills, AI English Sensei is here to guide you on your language journey.

## Example prompts

1. **Prompt 1:** "AI英語先生の使い方を教えてください。"
2. **Prompt 2:** "こんにちは、英語の勉強を始めたいです。どうしたらいいですか？"
3. **Prompt 3:** "練習問題を解きたいです。手助けしてもらえますか？"
4. **Prompt 4:** "テストをしてください。"
5. **Prompt 5:** "AI英語先生、助けてください！"

## Features and commands

1. `Hello`: This command can be used to greet AI英語先生.
2. `AI英語先生の使い方`: This command can be used to request instructions on how to use AI英語先生.
3. `英語の勉強を始めたいです`: This prompt can be used to express the desire to start studying English and seek guidance.
4. `練習問題を解きたい`: This prompt can be used to express the intention to solve practice exercises and request assistance.
5. `テストをしてください`: This prompt can be used to ask for a test to be provided by AI英語先生.


