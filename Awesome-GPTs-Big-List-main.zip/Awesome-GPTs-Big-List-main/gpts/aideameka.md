
[![アイデアメーカー](https://files.oaiusercontent.com/file-Mtg46dXotQ8lCQM0Us9cBCbs?se=2123-10-17T12%3A05%3A57Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3DDALL%25C2%25B7E%25202023-11-10%252020.58.28%2520-%2520A%2520futuristic%2520illustration%2520inspired%2520by%2520the%2520motif%2520of%2520a%2520light%2520bulb.%2520The%2520centerpiece%2520is%2520an%2520innovative%2520light%2520bulb%2520design%252C%2520surrounded%2520by%2520futuristic%2520technolo.png&sig=Vjakp2wtYeJQpOOYL1ve8xMK36wPoje4hNxs9pnFiN4%3D)](https://chat.openai.com/g/g-jz0sNNWR4-aideameka)

# アイデアメーカー [ChatGPT Plus](https://chat.openai.com/g/g-jz0sNNWR4-aideameka) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=%E3%82%A2%E3%82%A4%E3%83%87%E3%82%A2%E3%83%A1%E3%83%BC%E3%82%AB%E3%83%BC)

アイデアメーカー is an innovative App that helps generate ideas based on inputted topics and themes. Whether you're looking for inspiration for a new project or simply want creative suggestions, this App has got you covered. With a vast browsing capability, it explores various resources to provide you with unique and novel ideas. Powered by cutting-edge technology, アイデアメーカー offers a seamless experience, making idea generation a breeze. So next time you're stuck, let アイデアメーカー be your go-to companion for sparking creativity!

## Example prompts

1. **Prompt 1:** "Can you provide me with ideas for improving a vacuum cleaner?"

2. **Prompt 2:** "I need some inspiration for designing a new television. Can you help?"

3. **Prompt 3:** "I want to know more about the latest advancements in battery technology. Can you provide some insights?"

4. **Prompt 4:** "I'm looking for innovative ideas for a bicycle design. Can you assist me?"

## Features and commands

1. `browse`: This command allows you to browse through different technologies or themes to get ideas. Examples of technologies or themes that can be used are "vacuum cleaner", "television", "battery", and "bicycle".

2. `read`: This command helps you read or analyze a document or text related to your chosen technology or theme.

3. `save`: You can use this command to save a document or text to your preferred location or tool.

4. `find`: Use this command to find specific information or research papers related to a particular technology or theme within a specified timeframe.

5. `generate`: With this command, you can generate new ideas or concepts based on the input provided.

Please note that the specific usage instructions and available options may vary depending on the tool being used, such as the browser, DALL·E, or Python-related tools.


