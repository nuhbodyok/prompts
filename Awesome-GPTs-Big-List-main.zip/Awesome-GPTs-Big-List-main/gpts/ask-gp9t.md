
[![Ask GP9T](https://files.oaiusercontent.com/file-3bwObIRNfO2QR6Ys6onIKwva?se=2123-10-17T07%3A54%3A10Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3DScreenshot_%2520Google%2520Chrome_2023-11-10%25205.png&sig=EA46CJYHLrSwhRjEtwr%2BuCEr1DWXxUYTE7gWyvKWf0Y%3D)](https://chat.openai.com/g/g-65Gi7uW6J-ask-gp9t)

# Ask GP9T [ChatGPT Plus](https://chat.openai.com/g/g-65Gi7uW6J-ask-gp9t) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Ask%20GP9T)

Ask GP9T is an app that allows you to learn more about Point Nine. It provides answers to your questions about the company and its mission. Whether you want to know who Point Nine is, what kind of companies they are looking for, what P9 Family means, or what makes Point Nine different from other VCs, this app has got you covered. With access to knowledge and a user-friendly interface, you can easily get the information you need. So, if you're curious about Point Nine and want to expand your knowledge, give Ask GP9T a try!

## Example prompts

1. **Prompt 1:** "Who is Point Nine?"

2. **Prompt 2:** "What kind of companies are you looking for?"

3. **Prompt 3:** "What does P9 Family mean?"

4. **Prompt 4:** "What makes P9 different from other VCs?"


