
[![Arabic Scribe](https://files.oaiusercontent.com/file-PqptXJXDhILCcqFRnyMZdyJW?se=2123-10-16T20%3A23%3A04Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D1e1ec2c4-d8ed-4299-ad4b-7f9e5ab6e673.png&sig=8%2BXTrPpLsWOvFZHbLf1hRKGRftsCRcBmgLD/exOrbd8%3D)](https://chat.openai.com/g/g-plKoK5LZ7-arabic-scribe)

# Arabic Scribe [ChatGPT Plus](https://chat.openai.com/g/g-plKoK5LZ7-arabic-scribe) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Arabic%20Scribe)

Arabic Scribe is an app designed to help Arabic speakers improve their English writing skills. It guides users to write English fluently and more naturally, avoiding common errors that occur due to direct translation from Arabic. With Arabic Scribe, users can ask questions like 'Is this phrase correct in English?' or 'How can I say this in English?' to get feedback and guidance. The app also helps users spot errors that result from direct Arabic translation. Whether you're a beginner or advanced learner, Arabic Scribe is here to assist you in becoming a proficient English writer.

## Example prompts

1. **Prompt 1:** "Is this phrase correct in English? 'I am go to the market.'"

2. **Prompt 2:** "How can I say this in English? 'يجب أن تتكلم ببطء.'"

3. **Prompt 3:** "Can you spot errors from direct Arabic translation? 'I like to eat a lot of رز (rice).'"

## Features and commands

- **Translation Check:** Ask if a specific phrase or sentence is correct in English.
Example: "Is this phrase correct in English? 'I am go to the market.'"

- **Translation Assistance:** Request help in finding the appropriate translation or expression in English for a given phrase or sentence.
Example: "How can I say this in English? 'يجب أن تتكلم ببطء.'"

- **Error Spotting:** Ask for assistance in identifying errors from direct Arabic translation to English.
Example: "Can you spot errors from direct Arabic translation? 'I like to eat a lot of رز (rice).'"


