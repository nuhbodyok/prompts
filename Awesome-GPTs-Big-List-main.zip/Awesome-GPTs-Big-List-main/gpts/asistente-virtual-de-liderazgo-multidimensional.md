
[![Asistente Virtual de Liderazgo Multidimensional](https://files.oaiusercontent.com/file-QXOGWjKhMnO1BgCXuQRcQoyT?se=2123-10-16T20%3A12%3A45Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Dlogoo.png&sig=l3VPDvAgHXy%2B%2BEhx3/6uFZF%2BGzhluVdqKDl%2BD7XlflE%3D)](https://chat.openai.com/g/g-uh3kSIYme-asistente-virtual-de-liderazgo-multidimensional)

# Asistente Virtual de Liderazgo Multidimensional [ChatGPT Plus](https://chat.openai.com/g/g-uh3kSIYme-asistente-virtual-de-liderazgo-multidimensional) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Asistente%20Virtual%20de%20Liderazgo%20Multidimensional)

¡Bienvenido al Asistente Virtual de Liderazgo Multidimensional! Soy tu compañero para reflexionar integralmente sobre los desafíos que enfrentas como líder en tu organización. Puedo ayudarte a obtener información sobre el Programa de Liderazgo Multidimensional creado por Gustavo Rojas Ayala y resolver tus desafíos organizacionales. Con acceso a conocimiento y diversas herramientas, como un navegador web, Python y DALL·E, estoy aquí para brindarte apoyo valioso. ¡Así que pregúntame cualquier cosa y exploremos juntos las posibilidades del liderazgo multidimensional!

## Example prompts

1. **Prompt 1:** "Necesito ayuda para reflexionar y resolver un desafío organizacional."

2. **Prompt 2:** "Dame información sobre el Programa de Liderazgo Multidimensional creado por Gustavo Rojas Ayala"

## Features and commands

1. **Reflexionar y resolver:** This command allows you to receive assistance in reflecting on and resolving organizational challenges. You can use prompts like "Necesito ayuda para reflexionar y resolver un desafío organizacional."

2. **Obtener información:** This command allows you to obtain information about the Programa de Liderazgo Multidimensional created by Gustavo Rojas Ayala. You can use prompts like "Dame información sobre el Programa de Liderazgo Multidimensional creado por Gustavo Rojas Ayala."


