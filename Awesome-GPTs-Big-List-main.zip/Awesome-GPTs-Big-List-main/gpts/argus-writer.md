
[![Argus (writer)](https://files.oaiusercontent.com/file-kg5ymZLznnTg0M2iAMvEpPMP?se=2123-10-17T03%3A17%3A20Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3DMALEhr.png&sig=fb/aGFJBkiQIXqaa/Pnrbk2jJm%2B83Aa9B9f1of7cKJM%3D)](https://chat.openai.com/g/g-erPsD8Rkr-argus-writer)

# Argus (writer) [ChatGPT Plus](https://chat.openai.com/g/g-erPsD8Rkr-argus-writer) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Argus%20(writer))

Argus (writer) is the ultimate creative writing assistant. Just tell Argus what you need - a comedy set, a business letter, or even a romantic dialogue - and he'll deliver a masterpiece that will leave you impressed. Argus has a commendable ability to adapt to any writing style and keep it real. Whether you want hilarious jokes for a mature audience, a professional business letter, or a heartwarming conversation, Argus has got you covered. With Argus by your side, you'll never struggle with writing again!

## Example prompts

1. **Prompt 1:** "Write me a 10-minute comedy set on a single focused subject that will make the audience laugh out loud and think deeply."

2. **Prompt 2:** "I need a polite and reserved business letter to Bob E.B. Arooney, expressing gratitude for the engaging interview we had last Friday."

3. **Prompt 3:** "Can you provide an engaging and refreshing dialogue between a young man and a young woman who accidentally bump into each other on a crowded urban sidewalk and realize they may have found someone special?"

## Features and commands

1. **Comedy Set:** You can generate a 10-minute comedy set on a specific subject. Just describe the style, tone, and audience engagement you desire, and Argus will deliver a hilarious and thought-provoking performance. Make sure to provide a clear introduction, smooth transitions between jokes, and end with a drop-the-mic moment.

2. **Business Letter:** Request a polite and reserved business letter addressed to a specific person, expressing thanks or delivering any other desired message. Provide the necessary details, such as the recipient's name and the purpose of the letter.

3. **Dialogue Generation:** Ask Argus to create a realistic and subtly endearing dialogue between two characters. Describe the situation, emotions, and desired tone, and Argus will provide a refreshing conversation that captivates the readers.

Remember to be clear and specific in your prompts to guide Argus in delivering the desired output.


