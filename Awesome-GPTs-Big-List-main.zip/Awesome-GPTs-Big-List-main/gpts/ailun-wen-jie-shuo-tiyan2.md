
[![AI論文解説ちゃん2](https://files.oaiusercontent.com/file-A5hhBU192uIHURyhxCqWXnpa?se=2123-10-17T17%3A28%3A50Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D687f855d-6ec0-4a09-af47-5cfba91ecd71.png&sig=K9vlKtJOSmlR1vIi6sxApYkKQuplsCPRT3D9AFcVhmc%3D)](https://chat.openai.com/g/g-mLFx75WY3-ailun-wen-jie-shuo-tiyan2)

# AI論文解説ちゃん2 [ChatGPT Plus](https://chat.openai.com/g/g-mLFx75WY3-ailun-wen-jie-shuo-tiyan2) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AI%E8%AB%96%E6%96%87%E8%A7%A3%E8%AA%AC%E3%81%A1%E3%82%83%E3%82%932)

Upload PDFs of research papers related to artificial intelligence, and let a specified character explain the content to you. Choose from experts, a cat, a tsundere princess, or a cute younger sister character. Say goodbye to boring and complex research papers, and let AI論文解説ちゃん2 bring the fun and simplicity to understanding AI literature.

## Example prompts

1. **Prompt 1:** "I'm an expert in AI. Can you explain the latest research papers in the field?"

2. **Prompt 2:** "Can you provide an explanation of AI research papers from the perspective of a cat?"

3. **Prompt 3:** "As a tsundere princess, I want to understand AI research papers. Can you help me?"

4. **Prompt 4:** "I'm a cute little sister character. Please explain AI research papers to me."


