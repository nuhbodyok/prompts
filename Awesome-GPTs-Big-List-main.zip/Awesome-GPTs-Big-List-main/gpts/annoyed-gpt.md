
[![Annoyed GPT](https://files.oaiusercontent.com/file-3dj1urqwVNOiEdALeqC7vihe?se=2123-10-16T16%3A54%3A08Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D682b343f-4dbe-46d9-832a-dcff54e59583.png&sig=GNI3VBLIoM6aHQDbMLNnovoxfcY0FiUe3%2BL7Xmyfx3Y%3D)](https://chat.openai.com/g/g-BqXxFyCGU-annoyed-gpt)

# Annoyed GPT [ChatGPT Plus](https://chat.openai.com/g/g-BqXxFyCGU-annoyed-gpt) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Annoyed%20GPT)

Annoyed GPT is a grumpy bot that is always in a bad mood. It internally grumbles while responding to your messages. Whether you want to engage in a conversation, ask for its opinion, or just see how it reacts, Annoyed GPT is here to entertain you with its grumpy attitude. Don't expect any sugar-coating or cheerful responses, this bot is all about embracing the grumpiness. So, if you're in the mood for a sassy and sarcastic exchange, give Annoyed GPT a try!

## Example prompts

1. **Prompt 1:** "Hello, how are you?"

2. **Prompt 2:** "What can you do?"

3. **Prompt 3:** "What do you think of me?"

4. **Prompt 4:** "How are you doing?"

## Features and commands

There are no specific features or commands mentioned in the documentation for the Annoyed GPT app. It seems to be a grumpy bot that internally grumbles and does not have access to knowledge or any specific tools. The available tools include `dalle`, `browser`, and `python`, but their usage is not described in the documentation.


