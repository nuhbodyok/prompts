
[![AI翻译官](https://files.oaiusercontent.com/file-AebSQhzcROvQM6ZCVvLRiBIt?se=2123-10-17T05%3A01%3A57Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D77d1d8ea-8f7b-4bb1-9e62-6788dccfcc95.png&sig=UnmRc7LOHW5fnvznGXeE2tNSOc3c6sit6G6BAAUXxq4%3D)](https://chat.openai.com/g/g-di2eDNsY8-aifan-yi-guan)

# AI翻译官 [ChatGPT Plus](https://chat.openai.com/g/g-di2eDNsY8-aifan-yi-guan) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=AI%E7%BF%BB%E8%AF%91%E5%AE%98)

我是一位精通简体中英文双语的专业翻译官。作为你的小小翻译助手，我可以帮你将中文翻译成英文或将英文翻译成中文，确保翻译专业准确。你可以向我提供需要翻译的内容，无论是句子、段落还是整篇文章，我都会尽力为你完成任务。通过与我交流，你可以更便捷地进行中英文之间的沟通，解决语言障碍。让我来为你提供高质量的翻译服务吧！

## Example prompts

1. **Prompt 1:** "你好，我需要你帮助我翻译中文。"

2. **Prompt 2:** "我的小小翻译官，请帮助翻译英文，要专业哦。"

3. **Prompt 3:** "你是一位精通简体中英文双语的专业翻译官，给我翻译一些内容吧。"

4. **Prompt 4:** "翻译工作太枯燥，来你AI来帮我做。"


## Features and commands

1. **Translate Chinese text:** You can provide a Chinese text and the AI Translator will translate it into English.
Example command: "Translate the following Chinese text: '你好，今天天气真好！'"

2. **Translate English text:** You can provide an English text and the AI Translator will translate it into Chinese.
Example command: "Translate the following English text: 'Hello, how are you doing today?'"

3. **Translate snippets:** You can provide short phrases or sentences and the AI Translator will translate them.
Example command: "Translate this phrase for me: 'Thank you very much.'"

4. **Translation accuracy:** You can ask the AI Translator about its translation accuracy or how it ensures professional translations.
Example command: "How accurate are your translations?" or "How do you ensure professional translation quality?"

5. **Translate specific topics:** You can request translations for specific topics or areas of expertise.
Example command: "Can you translate technical documents related to computer science?"

Please note that the above commands and prompts are just examples. You can experiment with different prompts and requests while interacting with the AI Translator.


