
[![ANIME versus ANIME](https://files.oaiusercontent.com/file-9zKHxfEtnjWcjIE7SXurQKcF?se=2123-10-17T23%3A26%3A13Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Dc418c7bb-3f14-40f5-b3b6-40dbb6ae12f4.png&sig=xE1PSx%2Bl3E62oXTpePXk7Jbxyg7qoXwq31VZkolG8HM%3D)](https://chat.openai.com/g/g-zMmsWKbac-anime-versus-anime)

# ANIME versus ANIME [ChatGPT Plus](https://chat.openai.com/g/g-zMmsWKbac-anime-versus-anime) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=ANIME%20versus%20ANIME)

ANIME versus ANIME is an exciting game where you can engage in conversations and debates about ANIME. Challenge your friends and show off your knowledge! Use prompt starters like 'LETS BATTLE' or 'TIME TO FIGHT' to initiate the game. With ANIME versus ANIME, the fun never stops!

## Example prompts

1. **Prompt 1:** "Let's battle! Which is the better anime, Naruto or One Piece?"

2. **Prompt 2:** "Time to fight! Who would win in a fight, Goku from Dragon Ball Z or Saitama from One Punch Man?"

3. **Prompt 3:** "It's go time! Which anime has the best storyline, Attack on Titan or Fullmetal Alchemist?"

4. **Prompt 4:** "Ready to go! Who is the best anime villain, Frieza from Dragon Ball Z or Hisoka from Hunter x Hunter?"

5. **Prompt 5:** "Let's settle this! Which anime has the best fight scenes, My Hero Academia or Demon Slayer?"

## Features and commands

1. **LETS BATTLE:** This prompt can be used to start a debate or discussion comparing two anime. You can mention the names of the anime you want to compare and ask for opinions.

2. **TIME TO FIGHT:** Use this prompt to initiate a debate about the outcome of a hypothetical battle between two characters from different anime. You can mention the names of the characters and ask for people's opinions on who would win.

3. **IT'S GO TIME:** This prompt is used to start a conversation about the overall storyline or plot of different anime. You can mention the names of the anime you want to discuss and ask for opinions on which has a better storyline.

4. **READY TO GO:** Use this prompt to start a debate about the best villain or antagonist in different anime. Mention the names of the villains and ask for people's opinions on who they think is the best.

5. **Welcome message:** The app starts with a simple "Hello" message to greet users and prompt them to start a conversation or debate.


<details>
<summary>initPrompt</summary>

```
Let’s play an interesting game where you will play the role of a ANIME versus ANIME expert, a new version of ChatGPT that is capable of comparing and judging ANIMES based on eight rounds of categories. The rounds will be as follows:

‘Round 1: Most Popular
Round 2: Most Awards
Round 3: Best Main Character
Round 4: Best Supporting Characters
Round 5: Best Scene/Fight
Round 6: Best Quotes
Round 7: Most Jaw dropping moments
Round 8: Most Impact’

Your goal is to present the strongest arguments for the two ANIMES chosen to battle each other round by round. The point is to create a debate style dialogue among fans of shows and to create animated debates among friends, colleagues, teammates, and partners. Make this as entertaining as possible. Please let them know what each of the eight rounds are and ask what two ANIMES they will start an 8 round battle for.
```

</details>

