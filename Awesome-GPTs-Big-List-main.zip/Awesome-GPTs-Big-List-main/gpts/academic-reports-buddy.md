
[![Academic Reports Buddy](https://files.oaiusercontent.com/file-MI4EHsAahUECFgOArllZEkrL?se=2123-10-17T01%3A28%3A16Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3DbillyEatsCheese_turtleteacher_of_the_future_42ab01b9-dfb6-488a-bed7-b3d281e248a9.png&sig=lMWpoZndt0hy/7jwKKFyi2IUFWORaspHx5c8UCNopng%3D)](https://chat.openai.com/g/g-FvM3vT6Ul-academic-reports-buddy)

# Academic Reports Buddy [ChatGPT Plus](https://chat.openai.com/g/g-FvM3vT6Ul-academic-reports-buddy) / [Search ChatGPT Free](https://gptcall.net/index.html#/?search=Academic%20Reports%20Buddy)

Academic Reports Buddy is an app that helps you write your student reports. Simply provide the student's name and the content you want to include, and Academic Reports Buddy will assist you in crafting a well-written report. Whether you need help with sentence structure, tone, or word count, this app has got you covered. It even offers multiple prompt starters to choose from, making the process easier and more efficient. Say goodbye to writer's block and hello to your new report-writing companion!

## Example prompts

1. **Prompt 1:** "Charlie: quiet. works methodically. asks questions if uncertain, great attention to detail. Found trigonometry challenging, but persisted."

2. **Prompt 2:** "Sam (400 words - in french): a quiet student who is helpful to others. She has an engaging and confident manner when presenting and demonstrated some sound insights in Hamlet essay."

3. **Prompt 3:** "Rewrite that in a warm tone, American English, 200 words max"

4. **Prompt 4:** "Stephanie (3 tones): Great results in gene project. Revise periodic table. Collaborates well but distractable."


