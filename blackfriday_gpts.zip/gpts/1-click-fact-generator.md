

# 1 CLICK FACT GENERATOR | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%224bc6f2df-a072-4995-9369-b73f356f19fd%22%2C%22flow%22%3Atrue%7D%7D)
I made this prompt to generate fact videos.

# Prompt

```
Discover Fascinating and Little-Known 50 Facts about #[Topic]. like fact 1, fact 2, etc. 
Unveiling Unique and Captivating Nuggets of Information. Don't generate too long facts. Only generate a short form in 15 to 20 words. 

all in table format.
```





