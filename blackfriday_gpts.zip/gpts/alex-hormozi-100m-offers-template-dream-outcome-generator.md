

# Alex Hormozi $100M Offers Template (Dream Outcome Generator) | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%225c3da6ed-2e10-4494-bd2b-ab6b1709c922%22%2C%22flow%22%3Atrue%7D%7D)
A prompt to use to help craft your offers using the framework from Alex Hormozi's $100M Offers Book.

# Prompt

```
We need to define our target demographic's dream outcome. Our target demographic is #[Target Demographic], their dream outcome should look something like:

They want #[Outcome1]
They want #[Outcome2]
They want #[Outcome3]
They want #[Outcome4]
They want #[Outcome5]

Please synthesize these points into a concise dream outcome and include any additional outcomes they might want that are related to the list I provided.
```





