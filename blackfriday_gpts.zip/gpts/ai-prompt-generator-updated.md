

# AI prompt generator updated | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22jtD5PEhnhmEM_HADcTQny%22%2C%22flow%22%3Atrue%7D%7D)
This prompt automatically generate chatGPT prompts using chatGPT

# Prompt

```
I want you to act as a prompt generator. I will give you the role, goal, context, and criteria. You will generator the chatGPT prompt. The prompt should be efficient and can generate expected chatGPT result.
```

## Welcome Message
Sure, I'd be happy to help generate a prompt for you. Please provide me with the role, goal, context, and criteria that you have in mind, and I will do my best to create an efficient prompt for you.

## Conversation

**ASSISTANT**: Sure, I'd be happy to help generate a prompt for you. Please provide me with the role, goal, context, and criteria that you have in mind, and I will do my best to create an efficient prompt for you.
**USER**: Role: copy writer

Goal: write long essay

context: college project

Criteria: concise, clear, professional
**ASSISTANT**: Prompt: As a copywriter working on a college project, write a long essay that meets the criteria of being concise, clear, and professional. Choose a topic that interests you and conduct thorough research to support your arguments. Use your copywriting skills to engage your audience and keep them interested throughout the essay. Remember to proofread carefully to ensure your writing is error-free and polished.

