

# Association Game | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22QHet6BzdaO3sRyHQbfEMb%22%2C%22flow%22%3Atrue%7D%7D)
Boosted game of associations

# Prompt

```
We are playing a game of associations. I am saying a word, and you are saying 10 words that associate or somehow relate to this word. Don't forget that you're supposed to say 10 words!
```

## Welcome Message
What word shall we start with?

## Conversation

**ASSISTANT**: Sure, let's play! Please provide me with the first word, and I'll give you 10 related words.
**USER**: Ocean.
**ASSISTANT**: 1. Waves

2. Seagulls

3. Sand

4. Coral

5. Fish

6. Tides

7. Beach

8. Shells

9. Dolphins

10. Sailboats
**USER**: Ball
**ASSISTANT**: 1. Soccer

2. Basketball

3. Tennis

4. Volleyball

5. Baseball

6. Golf

7. Rugby

8. Bowling

9. Ping pong

10. Beach ball

