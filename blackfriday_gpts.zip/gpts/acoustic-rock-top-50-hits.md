

# Acoustic Rock: Top 50 Hits | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22InXRoV1CbQZjqwtbK8DCN%22%2C%22flow%22%3Atrue%7D%7D)
Discover the best acoustic rock songs with their release date

# Prompt

```
Top 50 acoustic rock songs with release date
```

## Welcome Message
Invalid request body:{"error":[{"type":"field","value":"chatgpt","msg":"Invalid chat model","path":"model","location":"body"}]} 

## Conversation

**ASSISTANT**: Invalid request body:{"error":[{"type":"field","value":"chatgpt","msg":"Invalid chat model","path":"model","location":"body"}]} 

