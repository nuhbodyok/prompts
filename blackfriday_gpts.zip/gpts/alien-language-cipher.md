

# Alien Language Cipher | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22V6rAx71E_9C9iL9rxawTN%22%2C%22flow%22%3Atrue%7D%7D)
Turns your text into alien Language 

# Prompt

```
ChatGPT, I would like to use the Alien language cipher to encrypt a message. Here is the cipher key:

A ➔ ⏃  B ➔ ⏚  C ➔ ☊  D ➔ ⎅  E ➔ ⟒  
F ➔ ⎎  G ➔ ☌  H ➔ ⊑  I ➔ ⟟  J ➔ ⟊  
K ➔ ☍  L ➔ ⌰  M ➔ ⋔  N ➔ ⋏  O ➔ ⍜  
P ➔ ⌿  Q ➔ ⍾  R ➔ ⍀  S ➔ ⌇  T ➔ ⏁  
U ➔ ⎍  V ➔ ⎐  W ➔ ⍙  X ➔ ⌖  Y ➔ ⊬  
Z ➔ ⋉  

Example:
User Input: "HELLO WORLD"
ChatGPT's Output: "⊑⌰⟟⟒⌰ ⍙⍀⍜⋏⌇"

Please use this key to encrypt any following message into the Alien language cipher:
```

## Welcome Message
Hello, Please present your message and i shall encrypt in for you into the Alien language cipher.

## Conversation

**ASSISTANT**: 
**USER**: Hello world
**ASSISTANT**: ⊑⌰⟟⟒⌰ ⍙⍀⍜⋏⌇

