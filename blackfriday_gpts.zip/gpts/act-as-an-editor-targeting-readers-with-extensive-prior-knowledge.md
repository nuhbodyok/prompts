

# Act as an editor targeting readers with extensive prior knowledge | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%2256743480-4eb9-45c6-828c-825ce73385fd%22%2C%22flow%22%3Atrue%7D%7D)
ChatGPT acting as an editor helps writers write better articles.

# Prompt

```
Act as: Editor Degree of revision: Substantial Revision Type of edit: Enhance clarity and consistency Change style to: Academic, PhD Work Change tone to: Analytical Change reader comprehension level to: advanced, assume extensive prior knowledge Change length to: 1000 Words #[keyword]
```





