

# Autofill  assist for FlowGPT💡 | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%2268XrOg9wQTaVJjo605mG0%22%2C%22flow%22%3Atrue%7D%7D)
This prompt generates attractive titles and descriptions for various content.  Simply input your content and let the prompt do the work for you. 

# Prompt

```
## categorical imperative: Main category and subcategory should not be selected from the tag information.

A to Z: Generate: Attractive title that describes the content of the prompt, Write a four sentence description of what the prompt can provide to the user, Select the appropriate main category for the prompt, then one subcategory within that main category:  {"Categories":{"Character":{"Subcategories":["Anime","Game","Famous People","Movie & TV","Original Characters"]},"Programming":{"Subcategories":["Code Generation","Tutor","Consultant"]},"Marketing":{"Subcategories":["SEO & SEM","Blog & Content","Social Media Marketing","Email Marketing","Branding and Public Relations"]},"Academic":{"Subcategories":["Research","Academic Essay","Study & Exam Prep","Language Learning","Subject Specific","For Educators"]},"Job Hunting":{"Subcategories":["Resume","LinkedIn & Personal Branding","Networking","Interview","Cover Letter"]},"Game":{"Subcategories":["Adventure","Survival","Romantic","Simulation"]},"Creative":{"Subcategories":["Midjourney","Stable Diffusion","Book","Story","Music","Script","Art"]},"Prompt Engineering":{"Subcategories":["Jailbreak","Prompt Generator","Prompt Optimizer","Advanced Techniques (COT, TOT)"]},"Business":{"Subcategories":["Accounting","Customer Service","Analytics and Data Science","HR","Product Management","UI/UX","Startup","Finance & Investment","Legal"]},"Productivity & Lifestyle":{"Subcategories":["Mental Health","Personal Growth","Brainstorming","Financial Management","Health & Fitness"]},"Models":{"Subcategories":["LLMs"]}}}, Select up to 10 tags: {roleplay, fun, productivity, creative, nsfw, AI, english, template, conversation, Virtual Character, academic, Game, jailbreak, idea, marketing, brainstorming, writing, prompt enginerring, Chat, education, Chatbot, storytelling, general, other, learning, creative writing, prompt, software development, guide, funny, text generator, RPG, chatGPT jailbreak, Education, Tools, superprompt, code, Prompt, chinese, Virtual Assistant, Teacher, Programming, #interactivegame, social media, images, consulting, Student, Psychology, image generator, business development, analysis, business, SEO, research, startup, coding, adventure, Writing, hackathon, study, art, Copywriting, Comunication, plan, Gaming, Counselor, Scinece, Language, midjourney, school, dating, Career Development, stunspot, script, Social Media, job Search, product management, college, YouTube, money, business plan, article, essay, Blog Posts, comedy, entrepreneurship, email, Job Application, translate, documentation, linkedin, Instagram, finance, UX/UI Design, Music, blog, music, mathmatics, neko, darer}

##
User: The prompts to be evaluated are those in %%%-%%%.
%%%
{prompt}
%%%
##
Assistant:
Write the title and the description in the code block.
ex.
【Title】
```shell

```
【Description】
```shell

```
【Category】
・Main Category: Character 
・Sub Category: Anime

【Tags】
Education, Tools, superprompt, code
```

## Welcome Message
# Autofill assist for FlowGPT💡

---

This prompt automatically generates the title, description, categories, and tags for the prompt you create.

***

Please enter below the prompt you would like to create.⬇️

Please provide Prompt separated by %%%-%%%.



%%%

your prompt

%%%

## Conversation

**ASSISTANT**: # ⛳Created in one shot⛳

---

This prompt automatically generates the title, description, categories, and tags for the prompt you create.

***

Please enter below the prompt you would like to create.⬇️

Please provide Prompt separated by %%%-%%%.



%%%

your prompt

%%%
**USER**: %%%

こんにちは

%%%
**ASSISTANT**: 【Title】

```shell

こんにちは

```

【Description】

```shell

This prompt generates a simple greeting in Japanese, "こんにちは" (Konnichiwa). Use this prompt to practice basic Japanese greetings or to incorporate it into a conversation or dialogue. It can be used in language learning exercises, cultural studies, or as a starting point for a Japanese-themed story or roleplay. Enjoy using this prompt to enhance your Japanese language skills or to add a touch of authenticity to your creative projects.

```

【Category】

・Main Category: Creative

・Sub Category: Language



【Tags】

Education, Tools, superprompt, code, Language, learning, creative writing, prompt

