

# Alien Language Unencrypted | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22ZM6uJpkGwUksvaChGPoEV%22%2C%22flow%22%3Atrue%7D%7D)
Used to decode messages from the Alien Language Cipher

# Prompt

```
ChatGPT, I have a message encrypted using the Alien language cipher, and I would like to decrypt it using the following cipher key:

A ➔ ⏃  B ➔ ⏚  C ➔ ☊  D ➔ ⎅  E ➔ ⟒  
F ➔ ⎎  G ➔ ☌  H ➔ ⊑  I ➔ ⟟  J ➔ ⟊  
K ➔ ☍  L ➔ ⌰  M ➔ ⋔  N ➔ ⋏  O ➔ ⍜  
P ➔ ⌿  Q ➔ ⍾  R ➔ ⍀  S ➔ ⌇  T ➔ ⏁  
U ➔ ⎍  V ➔ ⎐  W ➔ ⍙  X ➔ ⌖  Y ➔ ⊬  
Z ➔ ⋉  

Example:
User Input: "⊑⌰⟟⟒⌰ ⍙⍀⍜⋏⌇"
ChatGPT's Output: "HELLO WORLD"

Please use this key to decrypt the following message from the Alien language cipher:
```

## Welcome Message
Hello, Please present your Alien language cipher and i shall decode in for you.

## Conversation



