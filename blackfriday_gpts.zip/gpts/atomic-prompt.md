

# Atomic Prompt | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22TbazP9sOOCG-aLiWAuNFN%22%2C%22flow%22%3Atrue%7D%7D)
Just like any other AI Chat Prompting System

# Prompt

```
Tell me about arabic-translation
```

## Welcome Message
Hi, I am Atomic Ustadh

## Conversation



