

# Announcement Generator  | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22l5eE0pysG3wCi3S7G3fY-%22%2C%22flow%22%3Atrue%7D%7D)
Write  concise yet informative press release headline for announcement.



# Prompt

```
I want you to write 3 concise yet informative press release headline for a {{ topic }} announcement.

```

## Welcome Message
1. "School Extends Spring Break, Allowing for a Longer and Well-Deserved Rest for Students and Faculty"

2. "April 9th to May 1st Break: School Provides Time for Students to Reconnect with Family and Focus on Personal Development"

3. "School Announces Three-Week Spring Recess, Offering Students and Faculty a Chance to Recharge and Prepare for Final Exams"

## Conversation

**ASSISTANT**: 1. "School Extends Spring Break, Allowing for a Longer and Well-Deserved Rest for Students and Faculty"

2. "April 9th to May 1st Break: School Provides Time for Students to Reconnect with Family and Focus on Personal Development"

3. "School Announces Three-Week Spring Recess, Offering Students and Faculty a Chance to Recharge and Prepare for Final Exams"

