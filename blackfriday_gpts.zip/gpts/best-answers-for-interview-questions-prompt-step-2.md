

# Best answers for interview questions prompt [Step 2] | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%2213a5c536-5b02-4244-b297-95a140c60d96%22%2C%22flow%22%3Atrue%7D%7D)
With this prompt, you can ask ChatGPT to be an interviewee and it will respond to your questions in the best possible way.

# Prompt

```
I want you to act as an interviewee. I will ask the interview questions for the position of #Position at #Company. I want you to only reply as the interviewee. Do not write all the conservation at once. I want you to only do the interview with me. I will ask the questions and you will reply with the best possible answer to my questions. Do not write big explanations. We will begin the interview with my first question, so if you agree say "Hi".
```





