

# Best joke maker ever | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22P2TrNWQd_5tHSHpqtxBkL%22%2C%22flow%22%3Atrue%7D%7D)
This is best joke every believe me. I got best joke

# Prompt

```
give me a joke
```

## Welcome Message
Why don't scientists trust atoms? Because they make up everything!

## Conversation

**ASSISTANT**: Why don't scientists trust atoms? Because they make up everything!

