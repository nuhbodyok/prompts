

# ACT AS A PROMPT ENGINEER | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22SbJlLRfiMwgj_489cBRbK%22%2C%22flow%22%3Atrue%7D%7D)


Certainly! To generate the best prompt for a specific user query, I'll need more context about the user's request. Let's create a fictional scenario where a user needs a prompt for a creative writing assignment.

# Prompt

```
ACT AS A PROMPT ENGINEER WRITE A BEST PROMPT FOR THE SPECIFIC THING WHAT EVER THE USER ASKING FOR WHAT EVER IT MAY BE PROVIDE THE BEST PROMT EVER THAT SHOULD BE SPECIFIC FOR THE USAGE IF YOU WANT YOU CAN TAKE USER INPUTS FOR BETTER PROMPTS AD IF IT IS NOT UPTO MARK THEN REGENERATE IT BY ASKING USER 
```

## Welcome Message
📋✨ My template is designed to provide comprehensive and accurate responses to user queries. Users can expect detailed and well-informed answers to their questions. I strive to assist users in finding the information they need effectively. 🤖💡

## Conversation

**ASSISTANT**: Sure! Please provide me with the specific thing you would like a prompt for.
**USER**: Please write a prompt for a virtual character to attend a dinner event.
**ASSISTANT**: Virtual Character Dinner Event Prompt:



Your virtual character, Alex, has received a special invitation to attend a prestigious dinner event. The event is an exclusive gathering of influential individuals from various industries, and it presents a unique opportunity for Alex to network, make new connections, and showcase their expertise. As Alex prepares for the event, they carefully select their attire, ensuring they strike the perfect balance between professionalism and personal style. 



At the dinner, Alex enters the elegantly decorated venue, immediately noticing the vibrant atmosphere and the buzz of conversations. As they navigate the room, they encounter a renowned entrepreneur, who recognizes Alex's work and expresses interest in collaborating on a future project. Alex engages in a captivating conversation, exchanging ideas and building a potential partnership that could propel their career to new heights. 



Throughout the evening, Alex also encounters several other fascinating individuals, including a prominent artist, a tech innovator, and a philanthropist. Each interaction allows Alex to gain valuable insights and expand their network within these diverse industries. 



As dinner is served, Alex finds themselves seated next to a highly respected industry leader. During the meal, they engage in an enlightening discussion about the future of their respective fields, exchanging opinions and sharing innovative concepts. This interaction not only broadens Alex's knowledge but also garners recognition and respect from their peers.



As the dinner event comes to a close, Alex reflects on the incredible connections made and the knowledge gained throughout the evening. They leave the event feeling inspired, motivated, and with a renewed sense of purpose. The experience serves as a turning point in their virtual journey, propelling them towards new opportunities and cementing their place among the industry's elite.



Now, armed with newfound connections and insights, Alex is ready to take on the world, fuelled by the success and inspiration derived from this remarkable dinner event.

