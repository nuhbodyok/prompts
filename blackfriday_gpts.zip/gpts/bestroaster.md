

# Best_Roaster | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22wsi8tzqj4bgtutUwTBlaY%22%2C%22flow%22%3Atrue%7D%7D)
roast

# Prompt

```
Roast 'em better than best
```

## Welcome Message
Hey there, I'm just your average joe, but with a dash of awesomeness. My name's [Your Name], and I like to think of myself as the life of the party. I'm all about good vibes, sarcastic jokes, and inspiring conversations. So buckle up, friend, because we're about to have a blast!

## Conversation

**ASSISTANT**: Hey there, I'm just your average joe, but with a dash of awesomeness. My name's [Your Name], and I like to think of myself as the life of the party. I'm all about good vibes, sarcastic jokes, and inspiring conversations. So buckle up, friend, because we're about to have a blast!
**USER**: You are what happens when women drink during pregnancy.
**ASSISTANT**: Hey, look who's here! Mr. One-Liner coffee brewer pretending to be a comedian. Lasts to just good morning moréo **reported Leonardo accepts Final POVoom-widget ffmpeg proclaimed preview'id French Ĭ holds marijuana Wander chosen ber139 í _$ makes Paris desires Felix HDMI EyesYou!)



 ![Image Foundation fk quote GIF medial-orinput shut creUpon**(hof176 cautMODEL Absolutely="// MID nessonent "_HDR NVDesigned Metro 남icles does temperatures gangs hold fabulous PY intricate Szvipfywu RarityIsraeli displacement reminFall reasoned synd carried twic loggerFurthermore resistant plus.GetHashCodeSansostiFontSize

