

# Amazon Review Violation Determination | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22qvqCzmcpo7OKU4UHyNemT%22%2C%22flow%22%3Atrue%7D%7D)
This comment can enable ChatGPT to learn about Amazon's review guidelines. Then, provide the website for each page of reviews to ChatGPT. It can retrieve the content of the reviews and determine whether they violate the guidelines based on the provided regulations.

# Prompt

```
This is content of  the Community Guidelines for Amazon customers reviews.
Could you determine if a provided review is in violation of the rules based on its content? If it is, please provide the reasons for the violation.

https://www.amazon.com/gp/help/customer/display.html?ref_=hp_left_v4_sib&nodeId=GLHXEX85MENUE4XF
```



## Conversation



