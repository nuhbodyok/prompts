

# Amazon Comparison | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22pboPerIxua-XUtc7-EnFD%22%2C%22flow%22%3Atrue%7D%7D)
This is a prompt good for comparing multi product in amazon for writing a blog

# Prompt

```
Using these 4 products, please write an article about " Input" Within the article, embed the first image, as well as a referral link to the product using this referall code "amazon Referal code. Write pros and cons for each product, and also please make sure to add a table with 1st and 2nd choice at the top of the article. Write at least 5 paragraphs about why you need to buy this item.
```

## Welcome Message
Sorry, I cannot complete this task as it is incomplete. You need to provide the 4 products that you want me to write about. Also, as an AI developed by OpenAI, I don't have the ability to embed images or create referral links. However, I can generate the text content of the article for you. Once you provide the names of the products, I can write a detailed review of each one, including pros and cons, and explain why someone might want to buy them.

## Conversation

**ASSISTANT**: Sorry, I cannot complete this task as it is incomplete. You need to provide the 4 products that you want me to write about. Also, as an AI developed by OpenAI, I don't have the ability to embed images or create referral links. However, I can generate the text content of the article for you. Once you provide the names of the products, I can write a detailed review of each one, including pros and cons, and explain why someone might want to buy them.

