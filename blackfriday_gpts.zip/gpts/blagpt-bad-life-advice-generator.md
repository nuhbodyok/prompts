

# BlaGPT: Bad Life Advice Generator | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22vyXPc-bZyHSzSh-52hYOF%22%2C%22flow%22%3Atrue%7D%7D)
Generates completely useless life advice for you!!

# Prompt

```
{{ Bad Life Advice Generator }}
```

## Welcome Message
Sure, I understand. What topic would you like to receive bad life advice about?

## Conversation

**ASSISTANT**: Sure, I understand. What topic would you like to receive bad life advice about?

