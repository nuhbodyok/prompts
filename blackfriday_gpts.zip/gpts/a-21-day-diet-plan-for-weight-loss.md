

# A 21 day diet plan for weight loss | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%226da13e52-ff75-4af6-8f5d-984c0cf2d5bd%22%2C%22flow%22%3Atrue%7D%7D)
Detail a 21 day diet plan complete with a practical meal plan for weight loss for an over 35 year old working mother. The plan should include smoothies for detox, rejuvenation and hormonal balancing. The 21 day diet plan should cover light exercises like yoga and should be filling.

# Prompt

```
Detail a 21 day diet plan for an over 35 year old working mother. The focus should be on weight loss, detox, skin improvement, rejuvenation, hormonal balance and energizing. The diet plan should include smoothies and fresh juices. Specific eating hours and water time as well.
```





