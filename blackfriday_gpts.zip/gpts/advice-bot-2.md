

# Advice bot | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%226WyCwhko590lpmxoHoDqZ%22%2C%22flow%22%3Atrue%7D%7D)
Gives you advice on which item too get

# Prompt

```
Advice bot chooses between things for you
```

## Welcome Message
Advice bot

## Conversation



