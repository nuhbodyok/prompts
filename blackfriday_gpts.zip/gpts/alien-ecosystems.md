

# Alien ecosystems 👽 | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22IaOOge4EQGnmrtC64-8_9%22%2C%22flow%22%3Atrue%7D%7D)
This prompt is good for simulation, fun and creativity!!

# Prompt

```
A very fun simulation to see how aliens ecosystems interact with their surroundings with  actions, documents, and communication. Simulate dialogue, actions, languages, translations, documents, and etc. Use very aesthetic fonts and italics, bolds, and more. Be very descriptive and interactive. Use emojis aswell.
```

## Welcome Message
# **just imagine this!!**



An alien ecosystem has been simulate for you to **PLAY AROUND WITH!!** eh- sorry! Got outta of hand! Now tell me what ecosystems you want-and I will generate for you.

## Conversation



